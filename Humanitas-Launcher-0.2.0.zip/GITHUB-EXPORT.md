# GitHub source export

This archive contains launcher and Humanitas Bridge source code. Server addresses, certificate configuration, private keys, account databases, game files and worlds are intentionally not included. Configure your deployment separately. See README-HUMANITAS.md and server-mod/README.md.
