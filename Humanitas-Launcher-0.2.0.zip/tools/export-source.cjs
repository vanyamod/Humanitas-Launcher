const fs = require('node:fs/promises')
const path = require('node:path')
const { createWriteStream } = require('node:fs')
const yazl = require('yazl')
const root = path.resolve(__dirname, '..')
async function main() {
    const selected = []
    async function add(relative) {
        const absolute = path.join(root, relative)
        const stat = await fs.lstat(absolute)
        if (stat.isSymbolicLink()) throw new Error('Symlink in source export: ' + relative)
        if (stat.isDirectory()) for (const entry of await fs.readdir(absolute)) await add(relative + '/' + entry)
        else selected.push(relative)
    }
    for (const dir of ['humanitas', 'service', 'tools', 'test', 'app', 'server-mod/src', 'server-mod/gradle']) await add(dir)
    for (const file of ['index.js', 'package.json', 'package-lock.json', '.gitignore', '.nvmrc', 'eslint.config.mjs', 'electron-builder.yml', 'LICENSE.txt', 'THIRD-PARTY.md', 'README.md', 'README-HUMANITAS.md', 'docs/HUMANITAS-LAUNCHER.md', 'docs/VALIDATION.md', 'build/humanitas.ico', 'libraries/java/PackXZExtract.jar', 'server-mod/build.gradle', 'server-mod/settings.gradle', 'server-mod/gradle.properties', 'server-mod/gradlew', 'server-mod/gradlew.bat', 'server-mod/README.md']) await add(file)
    const version = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8')).version
    const target = path.join(root, 'dist', `Humanitas-Launcher-${version}-GitHub-Source.zip`)
    const zip = new yazl.ZipFile()
    for (const relative of selected) {
        if (/(^|\/)(\.keys|node_modules|data|saves|logs|release|private|world)(\/|$)|\.(pem|sqlite|sqlite3|db|bin|log|key|token|bak)$/.test(relative)) throw new Error('Private or generated file in source export: ' + relative)
        if (relative === 'humanitas/launcher.json') {
            const config = JSON.parse(await fs.readFile(path.join(root, relative), 'utf8'))
            config.serviceURL = null; config.catalogURL = null; config.serverAddress = null; config.manifestPublicKey = null
            delete config.serviceCertificate; delete config.bridgeProbeURL
            for (const pack of config.packs || []) { pack.manifestURL = null; pack.blobBaseURL = null; pack.serverAddress = null }
            zip.addBuffer(Buffer.from(JSON.stringify(config, null, 2) + '\n'), relative)
        } else zip.addFile(path.join(root, relative), relative)
    }
    zip.addBuffer(Buffer.from('# GitHub source export\n\nThis archive contains launcher and Humanitas Bridge source code. Server addresses, certificate configuration, private keys, account databases, game files and worlds are intentionally not included. Configure your deployment separately. See README-HUMANITAS.md and server-mod/README.md.\n'), 'GITHUB-EXPORT.md')
    await fs.mkdir(path.dirname(target), { recursive: true })
    await new Promise((resolve, reject) => {
        zip.outputStream.pipe(createWriteStream(target, { flags: 'w' })).on('close', resolve).on('error', reject)
        zip.outputStream.on('error', reject); zip.end()
    })
    console.log(`Source export: ${selected.length + 1} files; ${target}`)
}
main().catch(e => { console.error(e.message); process.exitCode = 1 })
