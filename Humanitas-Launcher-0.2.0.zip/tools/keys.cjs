const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
function keys() {
    const directory = path.resolve(__dirname, '..', '.keys')
    fs.mkdirSync(directory, { recursive: true, mode: 0o700 })
    const file = path.join(directory, 'pack-private.pem')
    if (!fs.existsSync(file)) {
        const pair = crypto.generateKeyPairSync('ed25519')
        fs.writeFileSync(file, pair.privateKey.export({ type: 'pkcs8', format: 'pem' }), { flag: 'wx', mode: 0o600 })
    }
    const privateKey = fs.readFileSync(file)
    const publicKey = crypto.createPublicKey(privateKey).export({ type: 'spki', format: 'pem' })
    fs.writeFileSync(path.join(directory, 'pack-public.pem'), publicKey)
    return { privateKey, publicKey }
}
if (require.main === module) { keys(); console.log('Ключи созданы в .keys. Закрытый ключ храните отдельно от публикации.') }
module.exports = { keys }
