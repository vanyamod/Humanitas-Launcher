const fs = require('node:fs')
const path = require('node:path')
const { serviceURL } = require('../humanitas/shared.cjs')
const args = process.argv.slice(2)
const option = flag => args[args.indexOf('--' + flag) + 1]
if (!args.includes('--url') || !args.includes('--server')) throw new Error('Нужно: node tools/configure.cjs --url https://accounts.ВАШ-ДОМЕН --server АДРЕС:ПОРТ')
const file = path.resolve(__dirname, '..', 'humanitas', 'launcher.json')
const config = JSON.parse(fs.readFileSync(file, 'utf8'))
config.serviceURL = serviceURL(option('url'))
if (args.includes('--cert')) config.serviceCertificate = fs.readFileSync(path.resolve(option('cert')), 'utf8')
else delete config.serviceCertificate
config.manifestPublicKey = fs.readFileSync(path.resolve(__dirname, '..', '.keys', 'pack-public.pem'), 'utf8')
const server = option('server')
if (!/^(\[[a-f\d:]+\]|[a-z\d.-]+)(?::\d{1,5})?$/i.test(server)) throw new Error('Неверный адрес сервера')
config.serverAddress = server
config.catalogURL = args.includes('--catalog') ? require('../humanitas/shared.cjs').downloadURL(option('catalog')) : null
config.packs = [{ id: 'humanitas', name: 'Humanitas', description: '', minecraft: config.minecraft, neoforge: config.neoforge,
    manifestURL: config.serviceURL + '/release/manifest.json', blobBaseURL: config.serviceURL + '/release', serverAddress: server }]
fs.copyFileSync(file, file + '.bak')
fs.writeFileSync(file, JSON.stringify(config, null, 2) + '\n')
console.log('Адреса и открытый ключ записаны. Закрытый ключ не включается в лаунчер.')
