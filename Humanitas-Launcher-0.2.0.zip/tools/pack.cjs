const fs = require('node:fs/promises')
const path = require('node:path')
const crypto = require('node:crypto')
const { hashFile } = require('../humanitas/files.cjs')
const { safePath, checkManifest, downloadURL } = require('../humanitas/shared.cjs')
const { keys } = require('./keys.cjs')
async function collect(source) {
    const files = []
    async function walk(relative) {
        for (const e of await fs.readdir(safePath(source, relative), { withFileTypes: true }).catch(err => { if (err.code === 'ENOENT') return []; throw err })) {
            const rel = relative + '/' + e.name
            if (e.isSymbolicLink()) throw new Error('Ссылки в исходной сборке запрещены: ' + rel)
            if (e.isDirectory()) { if (relative !== 'mods') await walk(rel); continue }
            if (!e.isFile() || (relative === 'mods' ? !/\.jar$/i.test(e.name) : !/\.(js|json|png|toml)$/i.test(e.name))) continue
            if (/\.(js|json|toml)$/.test(e.name)) {
                const text = await fs.readFile(safePath(source, rel), 'utf8')
                if (/(?:password|secret|accessToken|privateKey|webhook)\s*["']?\s*[:=]\s*["'][^"']{3,}["']/i.test(text)) throw new Error('Нужна ручная проверка приватных параметров: ' + rel)
            }
            files.push({ path: rel, mode: relative.startsWith('config') ? 'seed' : 'managed' })
        }
    }
    await walk('mods')
    for (const dir of ['kubejs/assets', 'kubejs/client_scripts', 'kubejs/server_scripts', 'kubejs/startup_scripts']) await walk(dir)
    if (await fs.stat(path.join(source, 'config', 'civitas-client.toml')).then(s => s.isFile(), () => false)) files.push({ path: 'config/civitas-client.toml', mode: 'seed' })
    return files.sort((a, b) => a.path.localeCompare(b.path))
}
async function makePack({ source, agent, output, version = 'season-2-preview', privateKey, publicKey, id = 'humanitas', name = 'Humanitas', publicBase = null, urlMap = {} }) {
    if (!/^[a-z0-9][a-z0-9_-]{0,47}$/.test(id)) throw new Error('Неверный id сборки')
    if (publicBase) publicBase = downloadURL(publicBase).replace(/\/$/, '')
    const selected = await collect(source)
    if (!selected.some(f => /Civitas-.*\.jar$/i.test(f.path))) throw new Error('В исходной сборке нет Civitas')
    const blobs = path.join(output, 'blobs')
    await fs.mkdir(blobs, { recursive: true })
    async function blob(file) {
        const sha256 = await hashFile(file), size = (await fs.stat(file)).size
        const target = path.join(blobs, sha256)
        await fs.copyFile(file, target)
        if (await hashFile(target) !== sha256) throw new Error('Файл изменился во время публикации')
        return { sha256, size }
    }
    const files = []
    for (const f of selected) files.push({ ...f, ...await blob(safePath(source, f.path)) })
    files.push({ path: 'config/fml.toml', mode: 'seed', ...await blob(path.resolve(__dirname, '..', 'humanitas', 'pack-defaults', 'fml.toml')) })
    for (const file of files) if (urlMap[file.path]) file.url = downloadURL(urlMap[file.path])
    const agentInfo = await blob(agent)
    if (urlMap['@agent']) agentInfo.url = downloadURL(urlMap['@agent'])
    const manifest = { schema: 1, id, version, minecraft: '1.21.1', neoforge: '21.1.250', generatedAt: new Date().toISOString(), files, agent: agentInfo }
    if (publicBase) manifest.blobBaseURL = publicBase
    const bytes = Buffer.from(JSON.stringify(manifest))
    const envelope = { payload: bytes.toString('base64'), signature: crypto.sign(null, bytes, privateKey).toString('base64') }
    checkManifest(envelope, publicKey)
    const manifestRelative = id === 'humanitas' ? 'manifest.json' : 'packs/' + id + '/manifest.json'
    const manifestPath = path.join(output, manifestRelative)
    await fs.mkdir(path.dirname(manifestPath), { recursive: true })
    await fs.writeFile(manifestPath + '.tmp', JSON.stringify(envelope, null, 2))
    await fs.rename(manifestPath + '.tmp', manifestPath)
    if (publicBase) {
        const catalogPath = path.join(output, 'catalog.json')
        const previous = await fs.readFile(catalogPath, 'utf8').then(JSON.parse).catch(e => { if (e.code === 'ENOENT') return []; throw e })
        const entry = { id, name, description: '', minecraft: manifest.minecraft, neoforge: manifest.neoforge, manifestURL: publicBase + '/' + manifestRelative, blobBaseURL: publicBase, serverAddress: null }
        await fs.writeFile(catalogPath + '.tmp', JSON.stringify([...previous.filter(p => p.id !== id), entry], null, 2))
        await fs.rename(catalogPath + '.tmp', catalogPath)
    }
    const report = { id, version, manifest: manifestRelative, files: files.length, bytes: files.reduce((sum, f) => sum + f.size, 0), includes: files.map(f => f.path), excludes: ['saves', 'logs', 'screenshots', 'maps', 'servers.dat', 'options.txt', 'accounts', 'keys', 'personal config/cache/history'], agent: manifest.agent }
    await fs.writeFile(path.join(output, '..', 'pack-report.json'), JSON.stringify(report, null, 2))
    return report
}
if (require.main === module) {
    const args = process.argv.slice(2), option = key => args[args.indexOf('--' + key) + 1]
    if (!args.includes('--source') || !args.includes('--agent')) throw new Error('Нужно: npm run pack -- --source ПАПКА_ПРОФИЛЯ --agent AUTHLIB_JAR [--version ВЕРСИЯ]')
    const urlMap = args.includes('--url-map') ? JSON.parse(require('node:fs').readFileSync(option('url-map'), 'utf8')) : {}
    makePack({ source: path.resolve(option('source')), agent: path.resolve(option('agent')), output: path.resolve(__dirname, '..', 'release', 'public'), version: args.includes('--version') ? option('version') : undefined,
        id: args.includes('--id') ? option('id') : undefined, name: args.includes('--name') ? option('name') : undefined, publicBase: args.includes('--public-base') ? option('public-base') : null, urlMap, ...keys() })
        .then(r => console.log(`Подписанная сборка: ${r.files} файлов, ${(r.bytes / 1024 ** 2).toFixed(1)} МБ. release/public`))
        .catch(e => { console.error(e.message); process.exitCode = 1 })
}
module.exports = { collect, makePack }
