const fs = require('node:fs/promises')
const nbt = require('prismarine-nbt')
const { serviceURL } = require('../humanitas/shared.cjs')
const { getJSON } = require('../humanitas/files.cjs')

function integer(value) {
    if (typeof value === 'bigint') return Number(value)
    if (Array.isArray(value)) return Number(BigInt(value[0]) * 4294967296n + BigInt(value[1] >>> 0))
    return Number(value)
}
async function readCivitas(file) {
    const stat = await fs.stat(file)
    if (stat.size > 64 * 1024 ** 2) throw new Error('Слишком большой SavedData')
    const { parsed } = await nbt.parse(await fs.readFile(file))
    const value = nbt.simplify(parsed)
    const saved = value.data || value
    if (!Array.isArray(saved.news)) throw new Error('В файле нет ленты Civitas')
    return saved.news.slice(0, 100).map(n => ({
        id: n.id, title: n.title, text: n.body + (n.footer ? '\n\n' + n.footer : ''),
        author: n.hideAuthor ? '' : n.author || '', stateName: n.hideState ? '' : n.stateName || '', published: integer(n.time)
    }))
}
async function main() {
    const args = process.argv.slice(2), option = flag => args[args.indexOf('--' + flag) + 1]
    if (!['--file', '--url', '--token-file'].every(f => args.includes(f))) throw new Error('Нужно: node tools/sync-civitas.cjs --file world/data/humanitas_res_publica.dat --url https://accounts.ДОМЕН --token-file ПРИВАТНЫЙ_ФАЙЛ [--pack humanitas] [--watch]')
    const base = serviceURL(option('url'), args.includes('--dev'))
    const token = (await fs.readFile(option('token-file'), 'utf8')).trim()
    if (token.length < 32) throw new Error('Некорректный ключ моста')
    let last = null, running = false
    const sync = async () => {
        if (running) return
        running = true
        try {
            const stamp = (await fs.stat(option('file'))).mtimeMs
            if (stamp === last) return
            const items = await readCivitas(option('file'))
            await getJSON(base + '/api/civitas/sync', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify({ pack: args.includes('--pack') ? option('pack') : 'humanitas', items }) })
            last = stamp; console.log('Civitas: синхронизировано новостей ' + items.length)
        } finally { running = false }
    }
    await sync()
    if (args.includes('--watch')) setInterval(() => sync().catch(e => console.error('Civitas: ' + e.message)), 15000)
}
if (require.main === module) main().catch(e => { console.error(e.message); process.exitCode = 1 })
module.exports = { readCivitas }
