const { _electron: electron } = require('playwright')
const fs = require('node:fs/promises')
const path = require('node:path')
const assert = require('node:assert/strict')
async function main() {
    const root = path.resolve(__dirname, '..')
    const directory = path.join(root, 'build', 'qa-packed')
    await fs.mkdir(directory, { recursive: true })
    const env = { ...process.env, HUMANITAS_QA: '1' }
    delete env.ELECTRON_RUN_AS_NODE
    const application = await electron.launch({ executablePath: process.env.HUMANITAS_PACKAGED_EXE || path.join(root, 'dist', '0.2.0', 'win-unpacked', 'Humanitas Launcher.exe'), args: ['--user-data-dir=' + path.join(directory, 'user')], env, timeout: 40000 })
    try {
        const page = await application.firstWindow()
        await page.locator('#app-version').filter({ hasText: '0.2.0' }).waitFor()
        const state = await page.evaluate(async () => window.humanitas.state())
        assert.ok(state.ok)
        assert.equal(state.data.connected, false)
        assert.equal(await page.evaluate(() => typeof require), 'undefined')
        const icon = await application.evaluate(async ({ app }) => (await app.getFileIcon(process.execPath, { size: 'large' })).toPNG().toString('base64'))
        await fs.writeFile(path.join(directory, 'exe-icon.png'), Buffer.from(icon, 'base64'))
        const exe = await fs.readFile(process.env.HUMANITAS_PACKAGED_EXE || path.join(root, 'dist', '0.2.0', 'win-unpacked', 'Humanitas Launcher.exe'))
        assert.ok(exe.includes(await fs.readFile(path.join(root, 'humanitas', 'ui', 'assets', 'icon.png'))), 'H icon pixels must be embedded in the executable')
        await page.locator('[data-page=settings]').click()
        await page.locator('#memory').waitFor()
        console.log('Packaged EXE: startup, isolated renderer, configuration, navigation PASS')
    } finally { await application.close() }
}
main().catch(e => { console.error(e); process.exitCode = 1 })
