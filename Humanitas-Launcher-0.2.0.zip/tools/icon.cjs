const fs = require('node:fs')
const path = require('node:path')
const { PNG } = require('pngjs')
const png = new PNG({ width: 256, height: 256 })
function rect(x, y, w, h, color) {
    const rgb = color.match(/../g).map(c => parseInt(c, 16))
    for (let yy = y * 4; yy < (y + h) * 4; yy++) for (let xx = x * 4; xx < (x + w) * 4; xx++) {
        const at = (yy * 256 + xx) * 4
        png.data[at] = rgb[0]; png.data[at + 1] = rgb[1]; png.data[at + 2] = rgb[2]; png.data[at + 3] = 255
    }
}
rect(6, 0, 52, 64, '0b100c'); rect(0, 6, 64, 52, '0b100c')
rect(6, 2, 52, 60, 'a99558'); rect(2, 6, 60, 52, 'a99558')
rect(8, 6, 48, 52, '4e5136'); rect(6, 10, 52, 44, '4e5136')
rect(10, 8, 44, 48, '1b231b'); rect(8, 12, 48, 40, '1b231b')
rect(17, 16, 8, 32, 'd6be78'); rect(39, 16, 8, 32, 'd6be78'); rect(25, 28, 14, 8, 'd6be78')
rect(17, 16, 8, 3, 'f0dc9a'); rect(39, 16, 8, 3, 'f0dc9a'); rect(25, 28, 14, 3, 'f0dc9a')
rect(17, 46, 8, 3, '7c6937'); rect(39, 46, 8, 3, '7c6937'); rect(28, 55, 8, 2, '8d8b56')
const buffer = PNG.sync.write(png), root = path.resolve(__dirname, '..')
fs.writeFileSync(path.join(root, 'humanitas', 'ui', 'assets', 'icon.png'), buffer)
const images = [16, 24, 32, 48, 64, 128].map(size => {
    const maskStride = Math.ceil(size / 32) * 4
    const dib = Buffer.alloc(40 + size * size * 4 + maskStride * size)
    dib.writeUInt32LE(40, 0); dib.writeInt32LE(size, 4); dib.writeInt32LE(size * 2, 8); dib.writeUInt16LE(1, 12); dib.writeUInt16LE(32, 14); dib.writeUInt32LE(size * size * 4, 20)
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
        const src = (Math.floor(y * 256 / size) * 256 + Math.floor(x * 256 / size)) * 4
        const dst = 40 + ((size - y - 1) * size + x) * 4
        dib[dst] = png.data[src + 2]; dib[dst + 1] = png.data[src + 1]; dib[dst + 2] = png.data[src]; dib[dst + 3] = png.data[src + 3]
        if (!png.data[src + 3]) dib[40 + size * size * 4 + (size - y - 1) * maskStride + Math.floor(x / 8)] |= 128 >> (x % 8)
    }
    return { size, bytes: dib }
})
images.push({ size: 256, bytes: buffer })
const header = Buffer.alloc(6 + images.length * 16)
header.writeUInt16LE(1, 2); header.writeUInt16LE(images.length, 4)
let offset = header.length
images.forEach((image, i) => {
    const at = 6 + i * 16
    header[at] = image.size % 256; header[at + 1] = image.size % 256
    header.writeUInt16LE(1, at + 4); header.writeUInt16LE(32, at + 6)
    header.writeUInt32LE(image.bytes.length, at + 8); header.writeUInt32LE(offset, at + 12); offset += image.bytes.length
})
const ico = Buffer.concat([header, ...images.map(image => image.bytes)])
fs.writeFileSync(path.join(root, 'build', 'humanitas.ico'), ico)
fs.writeFileSync(path.join(root, 'humanitas', 'ui', 'assets', 'icon.ico'), ico)
