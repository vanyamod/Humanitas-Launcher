const fs = require('node:fs/promises')
const path = require('node:path')
const { spawn } = require('node:child_process')
const { createService } = require('../service/server.cjs')
const { keys } = require('./keys.cjs')
const root = path.resolve(__dirname, '..')
async function main() {
    const directory = path.join(root, 'build', 'dev')
    await fs.mkdir(directory, { recursive: true })
    const { publicKey } = keys()
    const config = JSON.parse(await fs.readFile(path.join(root, 'humanitas', 'launcher.json'), 'utf8'))
    delete config.serviceCertificate
    config.serviceURL = 'http://127.0.0.1:18740'; config.manifestPublicKey = publicKey
    config.packs = config.packs.map(p => ({ ...p, manifestURL: config.serviceURL + '/release/manifest.json', blobBaseURL: config.serviceURL + '/release' }))
    const file = path.join(directory, 'launcher.json')
    await fs.writeFile(file, JSON.stringify(config, null, 2))
    const { server, store } = createService({ directory: path.join(directory, 'accounts'), release: path.join(root, 'release', 'public'), publicURL: config.serviceURL, development: true })
    await new Promise((resolve, reject) => { server.once('error', reject); server.listen(18740, '127.0.0.1', resolve) })
    console.log('Локальный сервис. Одноразовое приглашение: ' + store.invite())
    const env = { ...process.env, HUMANITAS_CONFIG: file, HUMANITAS_USER_DATA: path.join(directory, 'launcher-data') }
    delete env.ELECTRON_RUN_AS_NODE
    const child = spawn(require('electron'), ['.'], { cwd: root, env, windowsHide: true, stdio: ['ignore', 'inherit', 'inherit'] })
    child.on('close', () => server.close()); child.on('error', () => server.close())
}
main().catch(e => { console.error(e.message); process.exitCode = 1 })
