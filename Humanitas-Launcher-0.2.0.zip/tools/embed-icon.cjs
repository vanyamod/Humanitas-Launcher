const fs = require('node:fs/promises')
const path = require('node:path')
// Embed actual PE icon/version resources. No system icon cache changes or admin tools.
module.exports = async context => {
    if (context.electronPlatformName !== 'win32') return
    const R = await import('resedit')
    const file = path.join(context.appOutDir, 'Humanitas Launcher.exe')
    const binary = R.NtExecutable.from(await fs.readFile(file), { ignoreCert: true })
    const resources = R.NtExecutableResource.from(binary)
    for (let i = resources.entries.length - 1; i >= 0; i--) if ([3, 14].includes(resources.entries[i].type)) resources.entries.splice(i, 1)
    const icon = R.Data.IconFile.from(await fs.readFile(path.resolve(__dirname, '..', 'build', 'humanitas.ico')))
    R.Resource.IconGroupEntry.replaceIconsForResource(resources.entries, 1, 1033, icon.icons.map(item => item.data))
    const info = R.Resource.VersionInfo.fromEntries(resources.entries)[0] || R.Resource.VersionInfo.createEmpty()
    const version = context.packager.appInfo.version.split('.').map(Number)
    info.setFileVersion(version[0], version[1], version[2], 0, 1033)
    info.setProductVersion(version[0], version[1], version[2], 0, 1033)
    info.setStringValues({ lang: 1033, codepage: 1200 }, { ProductName: 'Humanitas Launcher', FileDescription: 'Humanitas Launcher', CompanyName: 'Humanitas', OriginalFilename: 'Humanitas Launcher.exe', LegalCopyright: 'Humanitas; Helios Launcher copyright Daniel D. Scalzi' })
    info.outputToResourceEntries(resources.entries)
    resources.outputResource(binary)
    await fs.writeFile(file, Buffer.from(binary.generate()))
}
