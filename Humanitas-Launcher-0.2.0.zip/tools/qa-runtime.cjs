const fs = require('node:fs/promises')
const path = require('node:path')
const crypto = require('node:crypto')
const assert = require('node:assert/strict')
const { createService } = require('../service/server.cjs')
const { Runtime } = require('../humanitas/runtime.cjs')
const { redact } = require('../humanitas/shared.cjs')
const { keys } = require('./keys.cjs')
const root = path.resolve(__dirname, '..')
async function main() {
    const directory = path.join(root, 'build', 'runtime-test')
    await fs.mkdir(directory, { recursive: true })
    const gameRoot = path.join(directory, 'game')
    await fs.mkdir(gameRoot, { recursive: true })
    await fs.writeFile(path.join(gameRoot, '.humanitas-launcher'), 'Isolated runtime QA\n')
    // Optional read-only cache reuse. Bytes are copied, never hard-linked to Modrinth.
    const cache = process.env.HUMANITAS_TEST_CACHE
    if (cache) {
        for (const dir of ['assets', 'libraries']) await fs.cp(path.join(cache, dir), path.join(gameRoot, 'runtime', dir), { recursive: true, force: false, errorOnExist: false })
    }
    const { server, store } = createService({ directory: path.join(directory, 'accounts'), release: path.join(root, 'release', 'public'), development: true })
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
    let runtime, timeout, child, reachedTitle = false
    try {
        const base = 'http://127.0.0.1:' + server.address().port
        const name = 'QA' + crypto.randomBytes(4).toString('hex')
        const user = await store.register(name, crypto.randomBytes(24).toString('hex'), store.invite())
        const session = store.issue(user, crypto.randomUUID())
        let last = ''
        runtime = new Runtime({ serviceURL: base, manifestPublicKey: keys().publicKey }, gameRoot, p => {
            if (p.stage !== last) { last = p.stage; console.log('Runtime QA: ' + p.stage) }
        })
        timeout = setTimeout(() => { runtime.cancel(); child?.kill(); }, 10 * 60000)
        const settings = { javaPath: process.env.HUMANITAS_TEST_JAVA || '', memoryMB: 6144, fullscreen: false, autoConnect: false }
        // A prior failed test may have generated defaults before the pack's seed was added.
        // Change only this explicitly-owned fixture, never a user's profile.
        const fixtureConfig = path.join(gameRoot, 'instances', 'humanitas', 'config')
        await fs.mkdir(fixtureConfig, { recursive: true })
        await fs.copyFile(path.join(root, 'humanitas', 'pack-defaults', 'fml.toml'), path.join(fixtureConfig, 'fml.toml'))
        const logPath = path.join(directory, 'game.log')
        await fs.writeFile(logPath, '')
        child = await runtime.start(settings, session)
        console.log('Runtime QA: Minecraft process started')
        const secret = [session.accessToken, session.clientToken]
        let logs = ''
        const write = data => { const safe = redact(data, secret); logs = (logs + safe).slice(-200000); fs.appendFile(logPath, safe).catch(() => {}) }
        child.stdout.on('data', write); child.stderr.on('data', write)
        await new Promise((resolve, reject) => {
            const timer = setInterval(() => {
                if (/Sound engine started|OpenAL initialized/.test(logs) && /Created:.*minecraft:textures\/atlas/.test(logs)) {
                    reachedTitle = true; clearInterval(timer); resolve()
                }
            }, 1000)
            child.once('error', e => { clearInterval(timer); reject(e) })
            child.once('close', code => { clearInterval(timer); reachedTitle ? resolve() : reject(new Error('Minecraft exited before initialization, code=' + code)) })
        })
        assert.ok(reachedTitle)
        await new Promise(resolve => setTimeout(resolve, 12000))
        const persisted = await fs.readFile(logPath, 'utf8')
        assert.ok(/authlib-injector.*Version: 1\.2\.8/.test(persisted))
        assert.ok(!/broken mod state|Mod loading has failed|ModLoadingCrashException/.test(persisted), 'modpack must not open a loading error screen')
        assert.ok(!persisted.includes(session.accessToken))
        console.log('Runtime QA PASS: Minecraft 1.21.1 + NeoForge 21.1.250 + full modpack + authlib-injector initialized')
        console.log('Log: ' + logPath)
    } finally {
        clearTimeout(timeout)
        // Stop only the isolated test child; never a user-started Minecraft process.
        if (child && child.exitCode == null) {
            child.kill()
            await new Promise(resolve => child.once('close', resolve))
        }
        await new Promise(resolve => server.close(resolve))
    }
}
main().catch(e => { console.error(e); process.exitCode = 1 })
