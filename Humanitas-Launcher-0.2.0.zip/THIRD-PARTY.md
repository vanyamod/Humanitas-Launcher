# Humanitas Launcher — attribution

Based on [Helios Launcher](https://github.com/dscalzi/HeliosLauncher), MIT,
Copyright (c) 2017–2026 Daniel D. Scalzi. Original license retained in LICENSE.txt.
The original UI in app/ is retained for reference and is not loaded or packaged.

Minecraft/NeoForge: @xmcl/core 2.15.1 and @xmcl/installer 6.1.2, MIT,
[source](https://github.com/Voxelum/minecraft-launcher-core-node).
These exact versions are pinned; newer inspected npm packages had invalid
workspace dependencies. Original library code is not patched.
Transitive undici is overridden to 7.30.1 to resolve published vulnerabilities.

Java discovery/distribution: helios-core, LGPL-3.0-only,
[source](https://github.com/dscalzi/helios-core), dynamically required unchanged.
Dependency licenses are retained in the packaged node_modules.

[authlib-injector](https://github.com/yushijinhun/authlib-injector), AGPL-3.0,
used as an independent unchanged Java agent, downloaded separately.
Local deployment artifact v1.2.8 SHA-256:
9c7f4343e6c82034958ffb48c14a2cb0c85928be7283103ce17da00c6d5a7b10.
[Corresponding source and license](https://github.com/yushijinhun/authlib-injector/tree/v1.2.8).
No agent binary is included in the source archive or launcher installer.

Press Start 2P: SIL OFL 1.1; see humanitas/ui/assets/FONT-LICENSE.txt.
Humanitas icon and world illustration are code-native pixel assets.
Windows executable resource editing: resedit, MIT, https://github.com/jet2jet/resedit-js.
Civitas SavedData reader: prismarine-nbt, MIT, https://github.com/PrismarineJS/prismarine-nbt.

Minecraft and NeoForge are downloaded from upstream endpoints.
Minecraft is a trademark of Mojang/Microsoft; this is an independent community project.
Mod licenses remain with their authors. release/ contains local deployment files,
not files for a public GitHub source export.
