# Humanitas Launcher 0.2.0

## Запуск

Node.js 22.20+ (ветка 22), Windows x64 для сборки EXE.

```powershell
npm ci
npm test
npm run lint
npm run test:ui
npm run dev
```

`dev` запускает локальный сервис 127.0.0.1:18740 и печатает одноразовый код регистрации.
Данные разработки: build/dev/accounts и build/dev/launcher-data. Production данные:
service/data либо HUMANITAS_AUTH_DATA. Они не включаются в исходники/установщик.
`npm start` открывает интерфейс с humanitas/launcher.json.

Для установки игры сначала подготовить release/public:

```powershell
npm run pack -- --source "ПАПКА_ПРОФИЛЯ" --agent "authlib-injector-1.2.8.jar"
```

Агент: https://github.com/yushijinhun/authlib-injector/releases/tag/v1.2.8.
SHA-256: 9c7f4343e6c82034958ffb48c14a2cb0c85928be7283103ce17da00c6d5a7b10.
Профиль-источник читается; миры, карты, логи, пароли и личная история не копируются.

## Изменения 0.2.0

Слоганы удалены. На главной — обновления Humanitas, ниже — новости Civitas.
Никаких примерных новостей в установленной программе не создаётся.
Настройки сохраняются при изменении; записи сериализованы и заменяются атомарно.
У каждой сборки своя instances/<id>; общий кеш Minecraft остаётся в runtime/.
Существующая instances/humanitas и сохранения не перемещаются.

Иконка встроена в PE-ресурсы EXE, включая размеры 16/24/32/48/64/128/256.
Windows AppUserModelID: org.humanitas.launcher. Ярлыки нового установщика используют
новый EXE. Если закреплён старый ярлык Electron, открепить его и закрепить обновлённый.
Глобальный кеш иконок Windows программа не удаляет.

## Администраторы и обновления

Администратор лаунчера — роль в сервисе аккаунтов. Она не назначается по нику,
не берётся из настроек клиента и не выдаётся при регистрации. После создания
аккаунта владелец сервиса назначает роль на хосте аккаунтов:

```sh
HUMANITAS_AUTH_DATA=/var/lib/humanitas/accounts node service/admin.cjs admin PlayerName
```

Для локального `npm run dev` в PowerShell:

```powershell
$env:HUMANITAS_AUTH_DATA = "ПОЛНЫЙ_ПУТЬ_ПРОЕКТА\build\dev\accounts"
node service/admin.cjs admin PlayerName
```

Назначение/снятие роли отзывает текущие сессии: войти заново. На главной и в новостях
появится «Написать». Доступны заголовок, текст, закрепление, редактирование и удаление.
Обычный аккаунт не может публиковать даже прямым запросом к API.
Команды: invite НИК (24 часа, точный ник), admin НИК, unadmin НИК, block НИК,
unblock НИК, logout НИК. Все команды выполняются с той же HUMANITAS_AUTH_DATA.

Публикации находятся в SQLite сервиса, не в news.json. Публичный GET /api/news
возвращает отдельные updates и civitas. Клиенты обновляют ленты каждые 15 секунд.
HTML/скрипты отображаются обычным текстом. Фото/модели из Civitas пока не переносятся.

## Новости из Civitas

Мод Civitas не пересобирается. Отдельный скрипт читает сохранённый
world/data/humanitas_res_publica.dat. Отправляются только опубликованные статьи:
id, заголовок, текст/подпись, дата и открытые имена автора/государства.
Флаги hideAuthor и hideState соблюдаются. Архив, законы, списки игроков и роли
не отправляются. Изменения появятся после сохранения мира Minecraft.

1. На сервере аккаунтов создать ключ `node service/admin.cjs bridge-key`.
2. Поместить этот ключ в CIVITAS_BRIDGE_TOKEN сервиса и в отдельный приватный файл
   на игровом сервере, например /etc/humanitas/bridge.key. В лаунчер ключ не включать.
3. На машине с доступом к миру запустить:

```sh
node tools/sync-civitas.cjs \
  --file /srv/minecraft/world/data/humanitas_res_publica.dat \
  --url https://accounts.YOUR-DOMAIN \
  --token-file /etc/humanitas/bridge.key --pack humanitas --watch
```

Для локального HTTP loopback добавить --dev. Одноразовая синхронизация — без --watch.
Снимок заменяет только ленту указанной сборки: удалённые в игре новости исчезнут
после следующего сохранения и синхронизации. Посты Humanitas не затрагиваются.
Без файла/ключа настоящая серверная лента не подключена; тестовые статьи не публикуются.

## Каталог и хранилище

Сервис аккаунтов и файлы сборок могут находиться на разных хостах.
Каталог по умолчанию: GET /api/catalog сервиса; файл настройки:
release/public/catalog.json. Дополнительно можно задать catalogURL в launcher.json
для отдельного HTTPS JSON. Каталог не требует повторной установки лаунчера.

Пример одного элемента каталога (массив таких объектов):

```json
[
  {
    "id": "humanitas",
    "name": "Humanitas",
    "description": "",
    "minecraft": "1.21.1",
    "neoforge": "21.1.250",
    "manifestURL": "https://files.YOUR-DOMAIN/manifest.json",
    "blobBaseURL": "https://files.YOUR-DOMAIN",
    "serverAddress": "play.YOUR-DOMAIN:25565"
  }
]
```

id определяет независимую папку и должен совпадать с id подписанного манифеста.
Сейчас поддерживаются Minecraft 1.21.1 и NeoForge 21.1.x. Каталог не обещает
поддержку Fabric/других версий без соответствующего установщика.

Для HTTPS/S3-совместимого хранилища (например R2 с публичным доменом) загрузить
ТОЛЬКО содержимое release/public. Ключи доступа S3 в лаунчер не включаются.
Публиковать с постоянными адресами; временные ссылки должны оставаться действующими
до обновления подписанного манифеста. Техническая документация R2:
https://developers.cloudflare.com/r2/buckets/public-buckets/.

Генерация файлов и каталога для заданного хранилища:

```powershell
npm run pack -- --source "ПАПКА_ПРОФИЛЯ" --agent "authlib-injector-1.2.8.jar" --id humanitas --name Humanitas --public-base https://files.YOUR-DOMAIN
```

Для второй сборки указать другой --id и --name. Общие blobs по SHA-256 не дублируются,
манифесты дополнительных сборок: packs/<id>/manifest.json. catalog.json пополняется.
Адрес игрового сервера задаётся в каталоге. Обновлять манифест после загрузки blobs.

Для индивидуальных прямых ссылок (в том числе файлов Google Drive) передать
--url-map public-urls.json. Пример файла:

```json
{
  "mods/Example.jar": "https://storage.YOUR-DOMAIN/direct-file",
  "@agent": "https://storage.YOUR-DOMAIN/authlib-injector.jar"
}
```

Ссылка должна отдавать файл, а не страницу просмотра/форму подтверждения. Переходы
разрешены только на HTTPS, хеш и размер всегда проверяются. Для Google Drive можно
использовать прямой webContentLink; у больших файлов/квот возможны подтверждения,
поэтому обычная ссылка на папку не является готовым источником сборки. OAuth входа
в Google и приватных ключей Drive в клиенте нет. Описание скачивания Drive:
https://developers.google.com/workspace/drive/api/guides/manage-downloads.
Если хранилище возвращает HTML, лаунчер останавливает установку с понятной ошибкой.

## Размещение сервиса

Сервис слушает только 127.0.0.1. Перед ним нужен HTTPS reverse proxy:

```sh
PUBLIC_URL=https://accounts.YOUR-DOMAIN \
HUMANITAS_AUTH_DATA=/var/lib/humanitas/accounts \
HUMANITAS_RELEASE=/srv/humanitas/release/public \
TRUST_LOOPBACK_PROXY=1 PORT=18740 node service/server.cjs
```

Caddy:

```caddy
accounts.YOUR-DOMAIN {
    reverse_proxy 127.0.0.1:18740 {
        header_up X-Real-IP {remote_host}
    }
}
```

Прокси должен заменять X-Real-IP. Хранить базу accounts.sqlite с WAL и
profile-private.pem вне веб-каталога; делать корректные SQLite backup.
Пакеты подписываются .keys/pack-private.pem. Не терять этот ключ и не публиковать
его на CDN/GitHub. В клиент включается только открытый ключ.

После выбора доменов и адреса сервера:

```powershell
npm run configure -- --url https://accounts.YOUR-DOMAIN --server play.YOUR-DOMAIN:25565
```

Если каталог хранится отдельно, добавить --catalog https://files.YOUR-DOMAIN/catalog.json.
Сервис аккаунтов всё равно нужен для входа и публикации; замена файлового хранилища
не меняет аккаунты игроков. В production только HTTPS.

## Игровой сервер

На сервере тот же authlib-injector с JVM аргументом:

```text
-javaagent:/opt/humanitas/authlib-injector-1.2.8.jar=https://accounts.YOUR-DOMAIN/yggdrasil/
```

Для новой тестовой копии с этой схемой online-mode=true и enforce-secure-profile=false.
На действующем сервере с прокси/иной авторизацией сначала проверить совместимость
и сделать резервную копию мира. Production server.properties автоматически не меняется.
UUID сервиса соответствует OfflinePlayer:<точный ник>. Старые online/proxy UUID
нужно сопоставлять отдельно, чтобы сохранить инвентари. Приглашения на существующие
ники выдавать только после проверки владельца.

## Сборка и проверка

```powershell
npm run dist:win -- --publish never --config.electronDist=node_modules/electron/dist --config.directories.output=dist/0.2.0
node tools/export-source.cjs
```

EXE пока не подписан сертификатом издателя. Подпись манифеста/хеши защищают
распространение файлов; они не доказывают неизменность компьютера после запуска.
Yggdrasil проверяет аккаунт, не служит аттестацией лаунчера. Автоматических банов
при отказе сервиса нет. Автообновление самого EXE пока не настроено.
Исходный профиль Modrinth, Civitas JAR и сохранения не изменяются.
