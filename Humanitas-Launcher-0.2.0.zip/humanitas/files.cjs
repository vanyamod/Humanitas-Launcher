const fs = require('node:fs/promises')
const { createReadStream } = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const { Agent } = require('undici')
const { safePath } = require('./shared.cjs')

async function hashFile(file) {
    const h = crypto.createHash('sha256')
    for await (const chunk of createReadStream(file)) h.update(chunk)
    return h.digest('hex')
}

async function rejectLinks(root, relative) {
    let current = root
    for (const part of relative.split('/')) {
        current = path.join(current, part)
        try {
            if ((await fs.lstat(current)).isSymbolicLink()) throw new Error('В каталоге сборки обнаружена ссылка: ' + relative)
        } catch (e) { if (e.code !== 'ENOENT') throw e }
    }
}

let trustedServiceOrigin = null, trustedServiceAgent = null
function setServiceCertificate(origin, certificate) {
    if (!origin && !certificate) { trustedServiceOrigin = null; trustedServiceAgent?.close(); trustedServiceAgent = null; return }
    const url = new URL(origin)
    if (url.protocol !== 'https:' || url.username || url.password || url.pathname !== '/' || url.search || url.hash || typeof certificate !== 'string' || !certificate.includes('-----BEGIN CERTIFICATE-----')) throw new Error('Некорректный сертификат сервиса')
    trustedServiceAgent?.close()
    trustedServiceOrigin = url.origin
    trustedServiceAgent = new Agent({ connect: { ca: certificate, rejectUnauthorized: true } })
}

async function fetchHTTPSRedirects(url, options = {}, allowed = false) {
    let current = url
    for (let redirects = 0; ; redirects++) {
        const dispatcher = trustedServiceAgent && new URL(current).origin === trustedServiceOrigin ? trustedServiceAgent : undefined
        const r = await fetch(current, { ...options, ...(dispatcher ? { dispatcher } : {}), redirect: 'manual', signal: options.signal || AbortSignal.timeout(20000) })
        if (r.status < 300 || r.status >= 400) return r
        await r.body?.cancel()
        if (!allowed || redirects >= 5) throw new Error('Недопустимое перенаправление загрузки')
        const next = new URL(r.headers.get('location'), current)
        if (next.protocol !== 'https:' || next.username || next.password) throw new Error('Перенаправление загрузки требует HTTPS')
        current = next.href
    }
}

async function getJSON(url, options = {}) {
    const { allowHTTPSRedirects, ...request } = options
    const r = await fetchHTTPSRedirects(url, request, allowHTTPSRedirects)
    let text = '', size = 0
    const decoder = new TextDecoder()
    if (r.body) for await (const chunk of r.body) {
        size += chunk.length
        text += decoder.decode(chunk, { stream: true })
        if (size > 6 * 1024 ** 2) throw new Error('Слишком большой ответ сервиса')
    }
    text += decoder.decode()
    let body
    try { body = text ? JSON.parse(text) : null } catch { throw new Error('Сервис вернул некорректный ответ') }
    if (!r.ok) throw Object.assign(new Error(body?.message || body?.errorMessage || `Сервис недоступен (${r.status})`), { status: r.status })
    return body
}

async function downloadVerified(url, target, expected, signal, progress = () => {}, options = {}) {
    await fs.mkdir(path.dirname(target), { recursive: true })
    const temp = target + '.' + crypto.randomBytes(6).toString('hex') + '.part'
    let handle
    try {
        const r = await fetchHTTPSRedirects(url, { signal: signal || AbortSignal.timeout(180000) }, options.allowHTTPSRedirects)
        if (!r.ok) throw new Error(`Не удалось скачать файл (${r.status})`)
        if (r.headers.get('content-type')?.includes('text/html')) throw new Error('Хранилище вернуло веб-страницу. Нужна прямая ссылка на файл без формы подтверждения.')
        handle = await fs.open(temp, 'wx')
        const h = crypto.createHash('sha256')
        let size = 0
        for await (const chunk of r.body) {
            size += chunk.length
            if (size > expected.size) throw new Error('Размер файла не совпадает')
            h.update(chunk)
            await handle.writeFile(chunk)
            progress(size)
        }
        await handle.close()
        handle = null
        if (size !== expected.size || h.digest('hex') !== expected.sha256) throw new Error('Контрольная сумма файла не совпадает')
        await fs.rename(temp, target)
    } finally {
        await handle?.close()
        await fs.rm(temp, { force: true })
    }
}

// Existing user configs are seeds: install once, retain edits on repair/update.
// Removed or extra mods move into a dated backup, never into the recycle bin.
async function syncPack(manifest, root, blobBase, { signal, progress = () => {} } = {}) {
    await fs.mkdir(root, { recursive: true })
    if ((await fs.lstat(root)).isSymbolicLink()) throw new Error('Каталог сборки не должен быть ссылкой')
    let index = 0
    for (const f of manifest.files) {
        signal?.throwIfAborted()
        const target = safePath(root, f.path)
        await rejectLinks(root, f.path)
        let valid = false
        try { valid = f.mode === 'seed' || ((await fs.stat(target)).size === f.size && await hashFile(target) === f.sha256) } catch (e) { if (e.code !== 'ENOENT') throw e }
        // Check existence separately: a missing seed must still be installed.
        if (f.mode === 'seed') valid = await fs.access(target).then(() => true, () => false)
        if (!valid) await downloadVerified(f.url || new URL('blobs/' + f.sha256, blobBase + '/'), target, f, signal, undefined, { allowHTTPSRedirects: true })
        progress({ stage: 'Сборка', detail: f.path, percent: ++index / manifest.files.length * 100 })
    }
    await rejectLinks(root, 'mods')
    const wanted = new Set(manifest.files.filter(f => f.path.startsWith('mods/')).map(f => f.path.slice(5).toLowerCase()))
    const mods = await fs.readdir(path.join(root, 'mods'), { withFileTypes: true }).catch(e => { if (e.code === 'ENOENT') return []; throw e })
    const backup = 'backups/' + new Date().toISOString().replace(/[:.]/g, '-')
    for (const entry of mods) {
        if (!/\.jar$/i.test(entry.name) || wanted.has(entry.name.toLowerCase())) continue
        if (!entry.isFile()) throw new Error('Посторонняя ссылка в mods')
        await rejectLinks(root, backup + '/' + entry.name)
        const to = safePath(root, backup + '/' + entry.name)
        await fs.mkdir(path.dirname(to), { recursive: true })
        await fs.rename(path.join(root, 'mods', entry.name), to)
    }
}

module.exports = { hashFile, rejectLinks, getJSON, downloadVerified, syncPack, setServiceCertificate }
