const api = window.humanitas
const $ = id => document.getElementById(id)
let state, registration = false, gameRunning = false, toastTimer, previousFocus, activeLayer = null, newsChannel = 'updates', editId = null
let saves = Promise.resolve(), saveSequence = 0, memoryTimer
async function call(promise) { const result = await promise; if (!result.ok) throw new Error(result.error); return result.data }
function toast(message) { $('toast').textContent = message; $('toast').hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('toast').hidden = true }, 6000) }
function action(id, fn) { $(id).addEventListener('click', async () => { try { await fn() } catch (e) { toast(e.message) } }) }
function page(name) {
    for (const section of document.querySelectorAll('.page')) section.hidden = section.id !== name
    for (const button of document.querySelectorAll('.nav')) { button.classList.toggle('active', button.dataset.page === name); button.setAttribute('aria-current', button.dataset.page === name ? 'page' : 'false') }
    document.querySelector('main').scrollTop = 0
}
function element(tag, className, text) { const node = document.createElement(tag); if (className) node.className = className; if (text != null) node.textContent = text; return node }
function meta(article) {
    const node = element('div', 'news-meta')
    node.append(element('b', '', article.channel === 'civitas' ? 'CIVITAS' : 'HUMANITAS'))
    if (Number.isFinite(article.published)) node.append(element('span', '', new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: 'long', year: 'numeric' }).format(article.published)))
    if (article.stateName) node.append(element('span', '', article.stateName))
    if (article.author) node.append(element('span', '', article.author))
    return node
}
function empty(message) { return element('div', 'empty-feed', message) }
function openModal(id, focus) {
    if (activeLayer) $(activeLayer).hidden = true
    else previousFocus = document.activeElement
    activeLayer = id; $(id).hidden = false; $(focus).focus()
}
function closeModal() {
    if (!activeLayer) return
    $(activeLayer).hidden = true; activeLayer = null
    $('password').value = ''; $('invite').value = ''
    if (previousFocus?.isConnected) previousFocus.focus()
}
function read(article) {
    $('reader-title').textContent = article.title; $('reader-text').textContent = article.text
    $('reader-meta').replaceChildren(...meta(article).childNodes)
    $('reader-actions').replaceChildren()
    if (state.account?.isAdmin && article.source === 'admin') {
        const edit = element('button', 'button secondary compact', 'Редактировать')
        edit.onclick = () => editor(article)
        const remove = element('button', 'button secondary compact danger', 'Удалить')
        remove.onclick = async () => {
            remove.disabled = true
            try { await call(api.deleteNews(article.id)); closeModal() } catch (e) { toast(e.message); remove.disabled = false }
        }
        $('reader-actions').append(edit, remove)
    }
    openModal('reader-layer', 'reader-close')
}
function card(article) {
    const node = element('article', 'news-card'); node.tabIndex = 0; node.setAttribute('role', 'button')
    node.append(meta(article), element('h3', '', article.title), element('p', '', article.text.length > 230 ? article.text.slice(0, 230) + '…' : article.text))
    node.onclick = () => read(article)
    node.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); read(article) } }
    return node
}
function renderNews() {
    const updates = state.news?.updates || [], civitas = state.news?.civitas || []
    const latest = updates[0], featured = $('featured')
    featured.replaceChildren(); featured.classList.toggle('empty', !latest)
    if (latest) {
        const actions = element('div', 'feature-actions'), button = element('button', 'text-button', 'Читать →')
        button.onclick = () => read(latest); actions.append(button)
        if (state.account?.isAdmin) { const edit = element('button', 'text-button', 'Редактировать'); edit.onclick = () => editor(latest); actions.append(edit) }
        featured.append(meta(latest), element('h2', '', latest.title), element('p', '', latest.text.length > 320 ? latest.text.slice(0, 320) + '…' : latest.text), actions)
    } else featured.textContent = 'Обновлений пока нет'
    $('home-news').replaceChildren(...(civitas.length ? civitas.slice(0, 2).map(card) : [empty('Нет опубликованных новостей Civitas')]))
    const list = newsChannel === 'civitas' ? civitas : updates
    $('all-news').replaceChildren(...(list.length ? list.map(card) : [empty('Нет опубликованных новостей')]))
    $('updates-tab').classList.toggle('active', newsChannel === 'updates'); $('civitas-tab').classList.toggle('active', newsChannel === 'civitas')
    for (const button of document.querySelectorAll('.write-news')) button.hidden = !state.account?.isAdmin
}
function editor(article = null) {
    if (!state.account?.isAdmin) return
    editId = article?.id || null
    $('editor-title').textContent = editId ? 'Редактирование новости' : 'Новость Humanitas'
    $('news-title').value = article?.title || ''; $('news-text').value = article?.text || ''; $('news-pinned').checked = !!article?.pinned
    $('news-submit').textContent = editId ? 'Обновить' : 'Опубликовать'; $('news-message').textContent = ''
    openModal('editor-layer', 'news-title')
}
function selected() { return state.packs.find(p => p.id === (state.selectedPack?.id || state.settings.selectedPack)) || state.packs[0] }
async function selectPack(id) {
    await flushSettings()
    state = await call(api.selectPack(id)); update(state)
}
function renderCatalog() {
    $('pack-catalog').replaceChildren(...state.packs.map(pack => {
        const isSelected = selected()?.id === pack.id, node = element('article', 'catalog-card' + (isSelected ? ' selected' : ''))
        node.dataset.pack = pack.id
        const top = element('div', 'catalog-top'), image = document.createElement('img'); image.src = 'assets/mark.svg'; image.alt = ''
        const info = element('div'); info.append(element('h2', '', pack.name), element('p', '', `Minecraft ${pack.minecraft} · NeoForge ${pack.neoforge}`)); top.append(image, info); node.append(top)
        if (pack.description) node.append(element('p', 'catalog-description', pack.description))
        const row = element('div', 'catalog-meta'); row.append(element('span', '', pack.installed ? 'Установлена' : 'Не установлена'), element('span', 'selected-label', isSelected ? 'Выбрана' : ''))
        const buttons = element('div', 'catalog-actions'), choose = element('button', 'button ' + (isSelected ? 'secondary' : 'primary'), isSelected ? 'Выбрана' : 'Выбрать')
        choose.disabled = isSelected || state.busy || gameRunning; choose.onclick = () => selectPack(pack.id).catch(e => toast(e.message))
        const install = element('button', 'button secondary', pack.installed ? 'Проверить' : 'Установить')
        install.disabled = state.busy || gameRunning || !pack.manifestURL || !state.downloadsReady
        install.onclick = async () => { try { await selectPack(pack.id); await call(api.prepare()) } catch (e) { toast(e.message) } }
        buttons.append(choose, install); node.append(row, buttons)
        if (!pack.manifestURL) node.append(element('p', 'catalog-note', 'Файлы не подключены'))
        return node
    }))
}
function applyPalette(palette) {
    document.body.dataset.palette = palette
    for (const button of document.querySelectorAll('.palette-choice')) button.setAttribute('aria-pressed', String(button.dataset.palette === palette))
}
function formSettings() {
    const s = state.settings
    applyPalette(s.palette || 'graphite')
    $('memory').max = state.maxMemory; $('memory').value = s.memoryMB; $('memory-value').textContent = `${s.memoryMB / 1024} ГБ`; $('memory-max').textContent = `${state.maxMemory / 1024} ГБ`
    $('fullscreen').checked = s.fullscreen; $('auto-connect').checked = s.autoConnect; $('remember').checked = s.remember
    $('data-directory').textContent = s.dataDirectory; $('java-path').textContent = s.javaPath || 'Определять автоматически'
}
function saveSetting(patch) {
    Object.assign(state.settings, patch)
    const sequence = ++saveSequence
    $('settings-status').textContent = ''
    saves = saves.catch(() => {}).then(async () => {
        const result = await call(api.settings(patch))
        if (sequence === saveSequence) { state.settings = result.settings; $('settings-status').textContent = 'Сохранено' }
    }).catch(e => { $('settings-status').textContent = e.message; throw e })
    saves.catch(() => {})
    return saves
}
async function flushSettings() {
    if (memoryTimer) { clearTimeout(memoryTimer); memoryTimer = null; saveSetting({ memoryMB: Number($('memory').value) }) }
    await saves
}
function update(value) {
    Object.assign(state, value)
    if (value.gameRunning != null) gameRunning = value.gameRunning
    $('account-name').textContent = state.account?.name || 'Гость'; $('account-caption').textContent = state.account?.isAdmin ? 'Администратор' : state.account ? 'Аккаунт Humanitas' : 'Войти в аккаунт'
    $('avatar').textContent = state.account?.name?.slice(0, 1).toUpperCase() || '?'
    const label = state.status.state === 'online' ? `${state.status.online} / ${state.status.max} игроков` : state.status.state === 'unconfigured' ? 'Сервер не подключён' : 'Сервер выключен'
    for (const el of document.querySelectorAll('.server-status')) el.textContent = label
    document.querySelector('.status-chip:has(.status-dot)').classList.toggle('online', state.status.state === 'online')
    $('bridge-status').textContent = state.bridgeStatus === 'service-online' ? 'Сервис: подключён' : state.bridgeStatus === 'online' ? 'Мост: ответил'  : state.bridgeStatus === 'unconfigured' ? 'Мост: не настроен' : state.bridgeStatus === 'unknown' ? 'Мост: проверка' : 'Мост: недоступен'
    if (value.news || 'account' in value) renderNews()
    if (value.packs || 'busy' in value || 'gameRunning' in value) renderCatalog()
    const p = state.progress, pack = selected()
    $('launch-title').textContent = gameRunning ? 'Minecraft работает' : p?.stage || pack?.name || 'Humanitas'
    $('launch-detail').textContent = p?.detail || (pack ? `Minecraft ${pack.minecraft} · NeoForge ${pack.neoforge}` : '')
    $('launch-detail').title = $('launch-detail').textContent; $('launch-detail').classList.toggle('error-text', !!p?.error)
    $('play-label').textContent = gameRunning ? 'В ИГРЕ' : state.busy ? 'ЗАГРУЗКА' : 'ИГРАТЬ'; $('play').disabled = state.busy || gameRunning
    $('cancel').hidden = !state.busy; $('progress-track').hidden = !state.busy; $('progress-track').classList.toggle('indeterminate', p?.percent == null)
    $('progress-fill').style.width = p?.percent == null ? '' : `${Math.max(0, Math.min(100, p.percent))}%`
    for (const id of ['reset', 'directory', 'java', 'memory', 'fullscreen', 'auto-connect', 'remember']) $(id).disabled = state.busy || gameRunning
    for (const button of document.querySelectorAll('.palette-choice')) button.disabled = state.busy || gameRunning
}
function authMode() {
    $('auth-title').textContent = state.account ? state.account.name : registration ? 'Регистрация' : 'Вход в Humanitas'
    $('auth-description').textContent = registration ? 'Регистрация по приглашению администрации.' : ''
    $('auth-submit').textContent = registration ? 'Создать аккаунт' : 'Войти'; $('invite-label').hidden = !registration; $('invite').required = registration
    $('password').minLength = registration ? 12 : 1; $('password').autocomplete = registration ? 'new-password' : 'current-password'
    $('auth-switch').textContent = registration ? 'Уже есть аккаунт? Войти' : 'Создать аккаунт'
    $('auth-form').hidden = !!state.account; $('auth-switch').hidden = !!state.account; $('logout').hidden = !state.account; $('auth-message').textContent = ''
}
function openAuth() { registration = false; authMode(); openModal('auth-layer', state.account ? 'logout' : 'username') }
document.addEventListener('keydown', e => {
    if (!activeLayer) return
    if (e.key === 'Escape') return closeModal()
    if (e.key !== 'Tab') return
    const inputs = [...$(activeLayer).querySelectorAll('button,input,textarea')].filter(el => !el.disabled && el.getClientRects().length)
    const first = inputs[0], last = inputs.at(-1)
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus() }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
})
async function boot() {
    state = await call(api.state()); $('app-version').textContent = state.version; $('discord').hidden = !state.links.discord
    formSettings(); update(state); api.onUpdate(update)
    for (const nav of document.querySelectorAll('[data-page]')) nav.onclick = () => page(nav.dataset.page)
    for (const button of document.querySelectorAll('.write-news')) button.onclick = () => editor()
    action('updates-tab', () => { newsChannel = 'updates'; renderNews() }); action('civitas-tab', () => { newsChannel = 'civitas'; renderNews() })
    action('civitas-all', () => { newsChannel = 'civitas'; renderNews(); page('news') })
    for (const key of ['minimize', 'maximize', 'close']) action(key, async () => { if (key === 'close') await flushSettings(); await call(api.window(key)) })
    action('account', openAuth); action('auth-close', closeModal); action('editor-close', closeModal); action('editor-cancel', closeModal); action('reader-close', closeModal)
    action('auth-switch', () => { registration = !registration; authMode(); $('username').focus() })
    action('logout', async () => { await call(api.logout()); closeModal() })
    action('play', async () => { await flushSettings(); if (!state.connected) return toast('Файлы выбранной сборки ещё не подключены'); if (!state.account) return openAuth(); await call(api.launch()) })
    action('cancel', () => call(api.cancel())); action('folder', () => call(api.openFolder())); action('discord', () => call(api.openLink('discord')))
    action('directory', async () => { await flushSettings(); state = await call(api.chooseDirectory()); formSettings() })
    action('java', async () => { await flushSettings(); state = await call(api.chooseJava()); formSettings() })
    action('reset', async () => { await flushSettings(); state = await call(api.settings({ reset: true })); formSettings(); $('settings-status').textContent = 'Сохранено' })
    $('memory').addEventListener('input', () => { $('memory-value').textContent = `${Number($('memory').value) / 1024} ГБ`; clearTimeout(memoryTimer); memoryTimer = setTimeout(() => { memoryTimer = null; saveSetting({ memoryMB: Number($('memory').value) }) }, 120) })
    $('memory').addEventListener('change', () => { clearTimeout(memoryTimer); memoryTimer = null; saveSetting({ memoryMB: Number($('memory').value) }) })
    for (const button of document.querySelectorAll('.palette-choice')) button.addEventListener('click', () => {
        const previous = state.settings.palette
        applyPalette(button.dataset.palette)
        saveSetting({ palette: button.dataset.palette }).catch(() => { state.settings.palette = previous; applyPalette(previous) })
    })
    for (const [id, key] of [['fullscreen', 'fullscreen'], ['auto-connect', 'autoConnect'], ['remember', 'remember']]) $(id).addEventListener('change', () => saveSetting({ [key]: $(id).checked }))
    $('auth-form').addEventListener('submit', async e => {
        e.preventDefault(); $('auth-submit').disabled = true; $('auth-message').textContent = ''
        const password = $('password').value; $('password').value = ''
        try {
            const input = { username: $('username').value.trim(), password, invite: $('invite').value.trim() }
            if (registration) { await call(api.register(input)); registration = false; authMode(); $('auth-message').textContent = 'Аккаунт создан. Введите пароль для входа.'; $('password').focus() }
            else { await call(api.login(input)); closeModal() }
        } catch (error) { $('auth-message').textContent = error.message } finally { $('auth-submit').disabled = false }
    })
    $('news-form').addEventListener('submit', async e => {
        e.preventDefault(); $('news-submit').disabled = true; $('news-message').textContent = ''
        try { await call(api.saveNews({ id: editId || undefined, title: $('news-title').value, text: $('news-text').value, pinned: $('news-pinned').checked })); closeModal() }
        catch (error) { $('news-message').textContent = error.message } finally { $('news-submit').disabled = false }
    })
}
boot().catch(e => toast('Не удалось открыть лаунчер: ' + e.message))
