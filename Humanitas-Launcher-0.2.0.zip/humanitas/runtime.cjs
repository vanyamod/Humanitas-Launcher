const fs = require('node:fs/promises')
const path = require('node:path')
const crypto = require('node:crypto')
const { Agent, interceptors } = require('undici')
const { setTimeout: sleep } = require('node:timers/promises')
const { promisify } = require('node:util')
const execFile = promisify(require('node:child_process').execFile)
const { Version, MinecraftFolder, launch } = require('@xmcl/core')
const installer = require('@xmcl/installer')
const java = require('helios-core/java')
const { getJSON, hashFile, downloadVerified, syncPack } = require('./files.cjs')
const { checkManifest } = require('./shared.cjs')
const { seedAssetsFromCache } = require('./asset-cache.cjs')

function networkRetryable(error) {
    const leaves = []
    const visit = (e, depth = 0) => {
        if (!e || depth > 20) return
        if (Array.isArray(e.errors) && e.errors.length) for (const child of e.errors) visit(child, depth + 1)
        else if (e.cause && !e.code && !e.phase) visit(e.cause, depth + 1)
        else leaves.push(e)
    }
    visit(error)
    const network = e => ['UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT', 'UND_ERR_BODY_TIMEOUT', 'UND_ERR_SOCKET', 'ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'EAI_AGAIN', 'ENOTFOUND'].includes(e.code)
    const failed = new Set(leaves.filter(network).map(e => e.destination).filter(Boolean))
    return leaves.some(network) && leaves.every(e => network(e) || (e.phase === 'validate' && failed.has(e.destination)))
}

class Runtime {
    constructor(config, dataRoot, progress, pack = null) {
        this.config = config
        this.root = dataRoot
        this.resource = path.join(dataRoot, 'runtime')
        this.pack = pack || { id: 'humanitas', manifestURL: config.serviceURL ? config.serviceURL + '/release/manifest.json' : null, blobBaseURL: config.serviceURL ? config.serviceURL + '/release' : null, serverAddress: config.serverAddress }
        this.instance = path.join(dataRoot, 'instances', this.pack.id)
        this.progress = progress
        this.task = null
        this.controller = null
        this.game = null
    }
    async java21(candidate) {
        if (!candidate) return false
        try {
            const { stderr, stdout } = await execFile(candidate, ['-XshowSettings:properties', '-version'], { timeout: 10000, windowsHide: true })
            return /java\.specification\.version\s*=\s*21\b/.test(stderr + stdout) && /sun\.arch\.data\.model\s*=\s*64/.test(stderr + stdout)
        } catch { return false }
    }
    async ensureJava(settings, signal) {
        this.progress({ stage: 'Java 21', detail: 'Проверка среды запуска', percent: null })
        if (settings.javaPath && await this.java21(settings.javaPath)) return settings.javaPath
        const found = await java.discoverBestJvmInstallation(this.root, '>=21 <22')
        if (found) return java.javaExecFromRoot(found.path)
        signal.throwIfAborted()
        const asset = await java.latestOpenJDK(21, this.root)
        if (!asset || asset.algo !== 'sha256') throw new Error('Не удалось найти Java 21. Укажите установленную Java в настройках.')
        await downloadVerified(asset.url, asset.path, { size: asset.size, sha256: asset.hash }, signal, bytes => this.progress({ stage: 'Java 21', detail: 'Загрузка среды запуска', percent: bytes / asset.size * 100 }), { allowHTTPSRedirects: true })
        signal.throwIfAborted()
        return java.extractJdk(asset.path)
    }
    async runTask(task, stage, signal) {
        this.task = task
        const cancel = () => { task.cancel().catch(() => {}) }
        signal.addEventListener('abort', cancel, { once: true })
        let last = 0
        const update = t => {
            if (Date.now() - last < 150) return
            last = Date.now()
            this.progress({ stage, detail: path.basename(t.to || t.name || ''), percent: task.total > 0 ? Math.min(100, task.progress / task.total * 100) : null })
        }
        try { signal.throwIfAborted(); return await task.startAndWait({ onStart: update, onUpdate: update }) }
        finally { signal.removeEventListener('abort', cancel); this.task = null }
    }
    async runTaskWithRetry(makeTask, stage, signal) {
        for (let attempt = 0; ; attempt++) {
            try { return await this.runTask(makeTask(), stage, signal) }
            catch (error) {
                signal.throwIfAborted()
                if (!networkRetryable(error)) {
                    if (error instanceof AggregateError) throw new Error(`Не удалось загрузить файлы: ${stage}. Повторите попытку.`, { cause: error })
                    throw error
                }
                if (attempt >= 2) throw new Error(`Не удалось подключиться к серверам загрузки: ${stage}. Проверьте интернет и повторите попытку.`, { cause: error })
                this.progress({ stage, detail: `Повторная попытка загрузки (${attempt + 2}/3)`, percent: null })
                await sleep(1000 * (attempt + 1), undefined, { signal })
            }
        }
    }
    async installAssetsBatched(version, options, signal) {
        const folder = MinecraftFolder.from(this.resource)
        const assetIndex = version.assetIndex
        if (!assetIndex || !/^[a-f0-9]{40}$/i.test(assetIndex.sha1) || !/^[a-zA-Z0-9_.-]+$/.test(assetIndex.id)) throw new Error('Не удалось проверить индекс ресурсов Minecraft')
        const logFile = version.logging?.client?.file
        if (logFile) await this.runTaskWithRetry(() => new installer.DownloadTask({ url: logFile.url, validator: { algorithm: 'sha1', hash: logFile.sha1 }, destination: folder.getLogConfig(logFile.id), dispatcher: options.dispatcher }), 'Ресурсы Minecraft', signal)
        await this.runTaskWithRetry(() => new installer.InstallAssetIndexTask(version, { ...options, useHashForAssetsIndex: true }), 'Индекс ресурсов Minecraft', signal)
        const indexFile = path.join(this.resource, 'assets', 'indexes', assetIndex.sha1 + '.json')
        const bytes = await fs.readFile(indexFile)
        if (crypto.createHash('sha1').update(bytes).digest('hex') !== assetIndex.sha1.toLowerCase()) throw new Error('Индекс ресурсов Minecraft повреждён')
        const objects = JSON.parse(bytes.toString('utf8')).objects
        if (!objects || typeof objects !== 'object') throw new Error('Некорректный индекс ресурсов Minecraft')
        const assets = Object.entries(objects).map(([name, item]) => ({ name, hash: item.hash, size: item.size }))
        if (assets.some(item => !/^[a-f0-9]{40}$/.test(item.hash) || !Number.isSafeInteger(item.size) || item.size < 0)) throw new Error('Некорректный индекс ресурсов Minecraft')
        const alias = path.join(this.resource, 'assets', 'indexes', assetIndex.id + '.json')
        if (alias !== indexFile) await fs.writeFile(alias, bytes)
        const modrinth = process.env.APPDATA && path.join(process.env.APPDATA, 'ModrinthApp', 'meta', 'assets')
        await seedAssetsFromCache(version, this.resource, modrinth, { signal, progress: ({ completed, total }) => this.progress({ stage: 'Подготовка ресурсов', detail: 'Проверка локального кэша', percent: completed / total * 100 }) })
        for (let i = 0; i < assets.length; i += 64) {
            signal.throwIfAborted()
            const group = assets.slice(i, i + 64)
            this.progress({ stage: 'Ресурсы Minecraft', detail: `Проверено ${i} из ${assets.length}`, percent: i / assets.length * 100 })
            await this.runTaskWithRetry(() => installer.installResolvedAssetsTask(group, folder, options), 'Ресурсы Minecraft', signal)
        }
    }
    async prepare(settings) {
        if (!this.pack.manifestURL || !this.config.manifestPublicKey) throw new Error('Файлы этой сборки ещё не подключены')
        if (this.controller || this.game) throw new Error('Дождитесь завершения текущего запуска')
        this.controller = new AbortController()
        const signal = this.controller.signal
        try {
            await fs.mkdir(this.root, { recursive: true })
            const marker = path.join(this.root, '.humanitas-launcher')
            const names = await fs.readdir(this.root)
            if (names.length && !names.includes('.humanitas-launcher')) throw new Error('Выберите отдельную пустую папку для Humanitas')
            await fs.writeFile(marker, 'Humanitas Launcher managed directory\n')
            this.progress({ stage: 'Проверка сборки', detail: 'Проверка подписи обновления', percent: null })
            const envelope = await getJSON(this.pack.manifestURL, { signal, allowHTTPSRedirects: true })
            const manifest = checkManifest(envelope, this.config.manifestPublicKey, { development: !!this.config.development })
            if (manifest.id !== this.pack.id) throw new Error('Манифест принадлежит другой сборке')
            const blobBase = manifest.blobBaseURL || this.pack.blobBaseURL || new URL('.', this.pack.manifestURL).href.replace(/\/$/, '')
            const javaPath = await this.ensureJava(settings, signal)
            signal.throwIfAborted()
            const versions = await installer.getVersionList({ fetch: (url, options) => fetch(url, { ...options, signal }) })
            const vanilla = versions.versions.find(v => v.id === manifest.minecraft)
            if (!vanilla) throw new Error('Версия Minecraft не найдена')
            // The installer schedules every asset at once; an explicit dispatcher bounds
            // actual connections and prevents thousands of simultaneous connection attempts.
            const dispatcher = new Agent({ connections: 6, connect: { timeout: 30000 }, headersTimeout: 30000, bodyTimeout: 60000 }).compose(interceptors.redirect({ maxRedirections: 5 }))
            let loaderId
            try {
                const options = { dispatcher, fetch: (url, opts) => fetch(url, { ...opts, signal }) }
                const vanillaVersion = await this.runTaskWithRetry(() => installer.installVersionTask(vanilla, this.resource, options), 'Minecraft ' + manifest.minecraft, signal)
                await this.installAssetsBatched(vanillaVersion, options, signal)
                await this.runTaskWithRetry(() => installer.installLibrariesTask(vanillaVersion, options), 'Библиотеки Minecraft', signal)
                // Keep the installer profile's id: NeoForge post-processing uses it internally.
                loaderId = await this.runTaskWithRetry(() => installer.installNeoForgedTask('neoforge', manifest.neoforge, this.resource, { java: javaPath, dispatcher }), 'NeoForge ' + manifest.neoforge, signal)
                const version = await Version.parse(this.resource, loaderId)
                if (!version.inheritances.includes(manifest.minecraft)) throw new Error('Версия NeoForge не совпадает с Minecraft сборки')
                if (version.assetIndex?.sha1 !== vanillaVersion.assetIndex?.sha1) await this.installAssetsBatched(version, options, signal)
                await this.runTaskWithRetry(() => installer.installLibrariesTask(version, options), 'Библиотеки и ресурсы', signal)
            } finally { await dispatcher.close() }
            await syncPack(manifest, this.instance, blobBase, { signal, progress: this.progress })
            if (!manifest.agent) throw new Error('В сборке отсутствует агент авторизации')
            const agentPath = path.join(this.root, 'auth', manifest.agent.sha256 + '.jar')
            if (await hashFile(agentPath).catch(() => '') !== manifest.agent.sha256) await downloadVerified(manifest.agent.url || blobBase + '/blobs/' + manifest.agent.sha256, agentPath, manifest.agent, signal, undefined, { allowHTTPSRedirects: true })
            signal.throwIfAborted()
            const state = { packVersion: manifest.version, minecraft: manifest.minecraft, neoforge: manifest.neoforge, files: manifest.files.length, loaderId, javaPath, agentPath }
            await fs.writeFile(path.join(this.root, 'installed.json'), JSON.stringify(state, null, 2))
            await fs.mkdir(path.join(this.root, 'packs'), { recursive: true })
            await fs.writeFile(path.join(this.root, 'packs', this.pack.id + '.json'), JSON.stringify(state, null, 2))
            this.progress({ stage: 'Готово к игре', detail: `${manifest.files.length} файлов проверено`, percent: 100 })
            return state
        } finally { this.controller = null }
    }
    async createTrustStore(javaPath, certificate) {
        if (!certificate) return null
        const bin = path.dirname(javaPath)
        const javaHome = path.dirname(bin)
        const source = path.join(javaHome, 'lib', 'security', 'cacerts')
        const keytool = path.join(bin, process.platform === 'win32' ? 'keytool.exe' : 'keytool')
        const root = path.join(this.root, 'auth')
        await fs.mkdir(root, { recursive: true })
        const suffix = crypto.randomBytes(8).toString('hex')
        const temporaryStore = path.join(root, 'trust-' + suffix + '.tmp')
        const temporaryCert = path.join(root, 'cert-' + suffix + '.pem')
        const target = path.join(root, 'humanitas-truststore')
        try {
            await fs.copyFile(source, temporaryStore)
            await fs.writeFile(temporaryCert, certificate, { mode: 0o600 })
            await execFile(keytool, ['-importcert', '-noprompt', '-alias', 'humanitas-service', '-file', temporaryCert, '-keystore', temporaryStore, '-storepass', 'changeit'], { timeout: 20000, windowsHide: true })
            await fs.rename(temporaryStore, target)
            return target
        } catch (e) { throw new Error('Не удалось настроить сертификат Java. Укажите полную Java 21 (JDK).', { cause: e }) }
        finally { await fs.rm(temporaryStore, { force: true }); await fs.rm(temporaryCert, { force: true }) }
    }
    async start(settings, session) {
        const installed = await this.prepare(settings)
        if (!session?.accessToken) throw new Error('Войдите в аккаунт Humanitas')
        this.progress({ stage: 'Запуск', detail: 'Minecraft ' + installed.minecraft, percent: null })
        const trustStore = await this.createTrustStore(installed.javaPath, this.config.serviceCertificate)
        const metadata = await getJSON(this.config.serviceURL + '/yggdrasil/')
        const extraJVMArgs = ['-Dauthlibinjector.yggdrasil.prefetched=' + Buffer.from(JSON.stringify(metadata)).toString('base64')]
        if (trustStore) extraJVMArgs.push('-Djavax.net.ssl.trustStore=' + trustStore, '-Djavax.net.ssl.trustStorePassword=changeit')
        this.game = await launch({
            gamePath: this.instance, resourcePath: this.resource, javaPath: installed.javaPath,
            version: installed.loaderId, gameProfile: session.selectedProfile, accessToken: session.accessToken,
            userType: 'mojang', launcherName: 'Humanitas', launcherBrand: 'humanitas', versionType: 'Humanitas',
            minMemory: Math.min(2048, settings.memoryMB), maxMemory: settings.memoryMB,
            resolution: { width: 1280, height: 720, fullscreen: settings.fullscreen },
            quickPlayMultiplayer: settings.autoConnect && this.pack.serverAddress ? this.pack.serverAddress : undefined,
            extraJVMArgs,
            yggdrasilAgent: { jar: installed.agentPath, server: this.config.serviceURL + '/yggdrasil/' },
            extraExecOption: { windowsHide: true, shell: false }
        })
        return this.game
    }
    cancel() { this.controller?.abort(new Error('Установка отменена')) }
}
module.exports = { Runtime, networkRetryable }

