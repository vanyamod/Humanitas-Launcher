const net = require('node:net')
function varint(value) {
    const out = []
    do { let b = value & 127; value >>>= 7; if (value) b |= 128; out.push(b) } while (value)
    return Buffer.from(out)
}
function readVarint(buffer, offset = 0) {
    let value = 0
    for (let i = 0; i < 5; i++) {
        if (offset + i >= buffer.length) return null
        const b = buffer[offset + i]
        value |= (b & 127) << (i * 7)
        if (!(b & 128)) return { value, length: i + 1 }
    }
    throw new Error('Неверный пакет статуса')
}
function ping(address) {
    if (!address) return Promise.resolve({ state: 'unconfigured' })
    const match = /^(\[[a-f\d:]+\]|[a-z\d.-]+)(?::(\d{1,5}))?$/i.exec(address)
    if (!match) return Promise.resolve({ state: 'invalid' })
    const host = match[1].replace(/^\[|\]$/g, '')
    const port = Number(match[2] || 25565)
    return new Promise(resolve => {
        let done = false
        const finish = result => { if (!done) { done = true; socket.destroy(); resolve(result) } }
        const socket = net.connect({ host, port })
        socket.setTimeout(3500, () => finish({ state: 'offline' }))
        socket.on('error', () => finish({ state: 'offline' }))
        socket.on('end', () => finish({ state: 'offline' }))
        socket.on('connect', () => {
            const h = Buffer.from(host)
            const p = Buffer.alloc(2); p.writeUInt16BE(port)
            const handshake = Buffer.concat([varint(0), varint(767), varint(h.length), h, p, varint(1)])
            socket.write(Buffer.concat([varint(handshake.length), handshake, Buffer.from([1, 0])]))
        })
        let buffer = Buffer.alloc(0)
        socket.on('data', chunk => {
            try {
                buffer = Buffer.concat([buffer, chunk])
                if (buffer.length > 32768) return finish({ state: 'offline' })
                const size = readVarint(buffer)
                if (!size || buffer.length < size.length + size.value) return
                const id = readVarint(buffer, size.length)
                if (!id || id.value !== 0) return finish({ state: 'offline' })
                const length = readVarint(buffer, size.length + id.length)
                if (!length) return
                const text = buffer.subarray(size.length + id.length + length.length, size.length + size.value).toString('utf8')
                const status = JSON.parse(text)
                finish({ state: 'online', online: Number(status.players?.online) || 0, max: Number(status.players?.max) || 0 })
            } catch { finish({ state: 'offline' }) }
        })
    })
}
// Public diagnostic only: never sends a token, credentials, or other private data.
async function probeBridge(value) {
    if (!value) return 'unconfigured'
    try {
        const url = new URL(value)
        if (url.protocol !== 'http:' || url.username || url.password || url.pathname !== '/health' || url.search || url.hash) return 'invalid'
        const response = await fetch(url, { method: 'GET', redirect: 'error', signal: AbortSignal.timeout(3000) })
        if (!response.ok || Number(response.headers.get('content-length') || 0) > 1024) return 'offline'
        const reader = response.body.getReader()
        let size = 0, text = ''
        for (;;) {
            const { value: chunk, done } = await reader.read()
            if (done) break
            size += chunk.length
            if (size > 1024) { await reader.cancel(); return 'offline' }
            text += Buffer.from(chunk).toString('utf8')
        }
        const body = JSON.parse(text)
        return body.service === 'humanitas-bridge' && body.status === 'probe' && body.auth === false ? 'online' : 'offline'
    } catch { return 'offline' }
}
module.exports = { ping, probeBridge }
