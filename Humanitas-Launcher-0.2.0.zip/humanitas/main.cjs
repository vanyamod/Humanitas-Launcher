const { app, BrowserWindow, ipcMain, dialog, shell, safeStorage } = require('electron')
const fs = require('node:fs/promises')
const path = require('node:path')
const os = require('node:os')
const crypto = require('node:crypto')
const { pathToFileURL } = require('node:url')
const { Runtime } = require('./runtime.cjs')
const { serviceURL, downloadURL, catalog, redact } = require('./shared.cjs')
const { getJSON, setServiceCertificate } = require('./files.cjs')
const { ping, probeBridge } = require('./status.cjs')

app.setName('Humanitas Launcher')
if (process.platform === 'win32') app.setAppUserModelId('org.humanitas.launcher')
if (app.commandLine.getSwitchValue('user-data-dir')) app.setPath('userData', path.resolve(app.commandLine.getSwitchValue('user-data-dir')))
if (!app.isPackaged && process.env.HUMANITAS_USER_DATA) app.setPath('userData', path.resolve(process.env.HUMANITAS_USER_DATA))
const single = app.requestSingleInstanceLock()
if (!single) app.quit()
let win, runtime, config, settings, session = null, accountInfo = null, packs = [], busy = false, status = { state: 'unconfigured' }, news = { updates: [], civitas: [] }, progress = null, bridgeStatus = 'unknown', timer
let settingsWrites = Promise.resolve(), pendingWrites = 0
const maxMemory = Math.max(2048, Math.floor((os.totalmem() / 1024 ** 2 - 2048) / 512) * 512)
const defaultMemory = Math.min(6144, maxMemory)
const palettes = ['graphite', 'bordeaux', 'midnight', 'malachite', 'terracotta', 'ash']
const fileURL = pathToFileURL(path.join(__dirname, 'ui', 'index.html')).href
const userFile = name => path.join(app.getPath('userData'), name)
function emit(extra = {}) {
    if (win && !win.isDestroyed()) win.webContents.send('humanitas:update', { busy, progress, account: session ? accountInfo || { ...session.selectedProfile, isAdmin: false } : null, status, ...extra })
}
async function saveSettings() {
    const bytes = JSON.stringify(settings, null, 2)
    pendingWrites++
    settingsWrites = settingsWrites.catch(() => {}).then(async () => {
        await fs.writeFile(userFile('settings.json.tmp'), bytes)
        await fs.rename(userFile('settings.json.tmp'), userFile('settings.json'))
    })
    try { await settingsWrites } finally { pendingWrites-- }
}
async function saveSession() {
    const file = userFile('session.bin')
    if (session && settings.remember && safeStorage.isEncryptionAvailable() && safeStorage.getSelectedStorageBackend?.() !== 'basic_text') {
        await fs.writeFile(file, safeStorage.encryptString(JSON.stringify({ serviceURL: config.serviceURL, session })))
    } else await fs.rm(file, { force: true })
}
async function auth(route, body) {
    if (!config.serviceURL) throw new Error('Сервис аккаунтов ещё не подключён')
    return getJSON(config.serviceURL + route, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
}
async function refresh() {
    if (!session) throw new Error('Войдите в аккаунт Humanitas')
    try {
        session = await auth('/yggdrasil/authserver/refresh', { accessToken: session.accessToken, clientToken: session.clientToken, requestUser: true })
        await saveSession()
    } catch (e) {
        if (e.status === 403) { session = null; accountInfo = null; await saveSession(); emit() }
        // Retain an encrypted session on a transient outage; server checks still gate launch.
        throw new Error('Не удалось подтвердить аккаунт: ' + e.message)
    }
}
function snapshot() {
    const selected = packs.find(p => p.id === settings.selectedPack)
    return { name: config.name, version: app.getVersion(), minecraft: config.minecraft, neoforge: config.neoforge,
        connected: !!selected?.manifestURL && !!config.manifestPublicKey, downloadsReady: !!config.manifestPublicKey, serviceURL: config.serviceURL,
        selectedPack: selected, packs, serverAddress: selected?.serverAddress, links: Object.fromEntries(Object.entries(config.links).map(([k, v]) => [k, !!v])),
        settings, maxMemory, busy, progress, bridgeStatus, account: session ? accountInfo || { ...session.selectedProfile, isAdmin: false } : null, status, news }
}
function configureRuntime() {
    const selected = packs.find(p => p.id === settings.selectedPack) || packs[0]
    if (!selected) throw new Error('В каталоге нет сборок')
    settings.selectedPack = selected.id
    runtime = new Runtime(config, settings.dataDirectory, value => {
        progress = value
        if (win) win.setProgressBar(value.percent == null ? 2 : value.percent / 100)
        emit()
    }, selected)
}
async function installationStates() {
    for (const p of packs) p.installed = await fs.access(path.join(settings.dataDirectory, 'packs', p.id + '.json')).then(() => true, () => false)
}
async function identity() {
    if (!session) { accountInfo = null; return }
    const token = session.accessToken
    let info
    try { info = await getJSON(config.serviceURL + '/api/me', { headers: { Authorization: 'Bearer ' + token } }) }
    catch (e) { if (session?.accessToken === token) throw e; return }
    if (session?.accessToken === token) accountInfo = info
}
async function checkServices() {
    const id = settings.selectedPack
    if (config.serviceURL) {
        try { bridgeStatus = (await getJSON(config.serviceURL + '/health'))?.status === 'ok' ? 'service-online' : 'offline' }
        catch { bridgeStatus = 'offline' }
    } else bridgeStatus = await probeBridge(config.bridgeProbeURL)
    const nextStatus = await ping(packs.find(p => p.id === id)?.serverAddress)
    if (id === settings.selectedPack) status = nextStatus
    const endpoint = config.catalogURL || (config.serviceURL ? config.serviceURL + '/api/catalog' : null)
    if (endpoint && !busy && !runtime.game) try {
        const next = catalog(await getJSON(endpoint, { allowHTTPSRedirects: true }), config.development)
        if (next.length && !busy && !runtime.game) {
            packs = next
            await installationStates()
            configureRuntime()
        }
    } catch { /* Keep the last validated catalog on a network outage. */ }
    if (config.serviceURL) {
        try {
            const latest = await getJSON(config.serviceURL + '/api/news')
            if (Array.isArray(latest?.updates) && Array.isArray(latest?.civitas)) news = { updates: latest.updates.slice(0, 100), civitas: latest.civitas.slice(0, 100) }
        } catch { /* Keep the previous feed on a network outage. */ }
        try { await identity() } catch (e) { if (e.status === 403) { session = null; accountInfo = null; await saveSession() } }
    }
    emit({ bridgeStatus, news, packs, selectedPack: packs.find(p => p.id === settings.selectedPack), connected: !!runtime.pack.manifestURL && !!config.manifestPublicKey })
}
async function operation(action) {
    if (busy || runtime.game) throw new Error('Дождитесь завершения текущего запуска')
    busy = true; emit()
    try { return await action() }
    catch (e) {
        const message = redact(e.message || String(e), [session?.accessToken, session?.clientToken])
        progress = { stage: 'Не удалось завершить', detail: message, error: true, percent: null }
        throw new Error(message)
    } finally { busy = false; win?.setProgressBar(-1); await installationStates(); emit({ packs }) }
}
function handler(name, fn) {
    ipcMain.handle('humanitas:' + name, async (event, input) => {
        if (event.senderFrame !== win?.webContents.mainFrame || event.senderFrame.url !== fileURL) throw new Error('Недопустимый источник запроса')
        try { return { ok: true, data: await fn(input) } }
        catch (e) { return { ok: false, error: redact(e.message, [session?.accessToken, session?.clientToken]) } }
    })
}
async function start() {
    await fs.mkdir(app.getPath('userData'), { recursive: true })
    config = JSON.parse(await fs.readFile(!app.isPackaged && process.env.HUMANITAS_CONFIG || path.join(__dirname, 'launcher.json'), 'utf8'))
    config.development = !app.isPackaged
    if (config.serviceURL) config.serviceURL = serviceURL(config.serviceURL, !app.isPackaged)
    if (config.serviceCertificate) {
        if (!config.serviceURL) throw new Error('Для сертификата нужен адрес сервиса')
        setServiceCertificate(new URL(config.serviceURL).origin, config.serviceCertificate)
    }
    if (config.catalogURL) config.catalogURL = downloadURL(config.catalogURL, config.development)
    if (config.serverAddress && !/^(\[[a-f\d:]+\]|[a-z\d.-]+)(?::\d{1,5})?$/i.test(config.serverAddress)) throw new Error('Некорректный адрес Minecraft сервера')
    settings = { palette: 'graphite', memoryMB: defaultMemory, fullscreen: false, autoConnect: true, remember: true, javaPath: '', selectedPack: 'humanitas', dataDirectory: path.join(app.getPath('appData'), '.humanitas') }
    const saved = await fs.readFile(userFile('settings.json'), 'utf8').then(JSON.parse).catch(() => null)
    if (saved) {
        if (palettes.includes(saved.palette)) settings.palette = saved.palette
        for (const key of ['dataDirectory', 'javaPath', 'selectedPack']) if (typeof saved[key] === 'string') settings[key] = saved[key]
        for (const key of ['fullscreen', 'autoConnect', 'remember']) if (typeof saved[key] === 'boolean') settings[key] = saved[key]
        settings.memoryMB = Math.min(maxMemory, Math.max(2048, Number(saved.memoryMB) || defaultMemory))
    }
    if (safeStorage.isEncryptionAvailable()) {
        try {
            const stored = JSON.parse(safeStorage.decryptString(await fs.readFile(userFile('session.bin'))))
            if (stored.serviceURL === config.serviceURL && settings.remember) session = stored.session
        } catch { /* First start or OS key changed. */ }
    }
    packs = catalog(config.packs || [{ id: 'humanitas', name: 'Humanitas', minecraft: config.minecraft, neoforge: config.neoforge, manifestURL: config.serviceURL ? config.serviceURL + '/release/manifest.json' : null, blobBaseURL: config.serviceURL ? config.serviceURL + '/release' : null, serverAddress: config.serverAddress }], config.development)
    if (config.serviceURL && !packs.some(p => p.manifestURL)) packs[0].manifestURL = config.serviceURL + '/release/manifest.json'
    if (config.serviceURL && !packs[0].blobBaseURL) packs[0].blobBaseURL = config.serviceURL + '/release'
    await installationStates()
    configureRuntime()
    win = new BrowserWindow({ width: 1240, height: 820, minWidth: 980, minHeight: 680, frame: false, transparent: true,
        show: process.env.HUMANITAS_QA !== '1', title: 'Humanitas Launcher', backgroundColor: '#101212',
        icon: path.join(__dirname, 'ui', 'assets', 'icon.png'),
        webPreferences: { preload: path.join(__dirname, 'preload.cjs'), sandbox: true, contextIsolation: true, nodeIntegration: false, webSecurity: true, devTools: !app.isPackaged }
    })
    win.removeMenu()
    if (process.platform === 'win32') win.setAppDetails({ appId: 'org.humanitas.launcher', appIconPath: app.isPackaged ? process.execPath : path.join(__dirname, 'ui', 'assets', 'icon.ico'), appIconIndex: 0, relaunchDisplayName: 'Humanitas Launcher' })
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }))
    win.webContents.on('will-navigate', e => e.preventDefault())
    win.webContents.session.setPermissionRequestHandler((_webContents, _permission, callback) => callback(false))
    win.on('close', async e => {
        if (pendingWrites) { e.preventDefault(); await settingsWrites.catch(() => {}); win.close(); return }
        if (!busy && !runtime.game) return
        e.preventDefault()
        if (runtime.game) {
            const answer = await dialog.showMessageBox(win, { type: 'question', message: 'Minecraft работает. Закрыть лаунчер?', detail: 'Игра продолжит работать.', buttons: ['Остаться', 'Закрыть'], defaultId: 0, cancelId: 0 })
            if (answer.response === 1) { runtime.game.unref(); win.destroy(); app.quit() }
        } else {
            const answer = await dialog.showMessageBox(win, { type: 'question', message: 'Отменить установку и закрыть лаунчер?', buttons: ['Продолжить', 'Закрыть'], defaultId: 0, cancelId: 0 })
            if (answer.response === 1) { runtime.cancel(); win.destroy(); app.quit() }
        }
    })
    handler('state', snapshot)
    handler('login', async b => {
        if (busy || runtime.game) throw new Error('Дождитесь завершения игры или установки')
        if (typeof b?.username !== 'string' || typeof b.password !== 'string' || b.username.length > 128 || b.password.length > 128) throw new Error('Проверьте ник и пароль')
        session = await auth('/yggdrasil/authserver/authenticate', { username: b.username, password: b.password, clientToken: crypto.randomUUID(), requestUser: true, agent: { name: 'Minecraft', version: 1 } })
        await identity(); await saveSession(); emit(); return accountInfo
    })
    handler('register', async b => {
        if (!b || typeof b.username !== 'string' || typeof b.password !== 'string' || typeof b.invite !== 'string') throw new Error('Заполните поля')
        return auth('/api/register', { username: b.username, password: b.password, invite: b.invite })
    })
    handler('logout', async () => {
        if (busy || runtime.game) throw new Error('Сначала завершите игру или установку')
        if (session) {
            // Do not claim server-side logout when the revoke request failed.
            try { await auth('/yggdrasil/authserver/invalidate', { accessToken: session.accessToken, clientToken: session.clientToken }) }
            catch (e) { if (e.status !== 403) throw e }
        }
        session = null; accountInfo = null; await saveSession(); emit()
    })
    handler('settings', async b => {
        if (busy || runtime.game) throw new Error('Настройки доступны после завершения игры или установки')
        if (b?.reset === true) { settings.memoryMB = defaultMemory; settings.fullscreen = false; settings.autoConnect = true; settings.remember = true; settings.javaPath = ''; settings.palette = 'graphite' }
        else {
            if (b?.palette != null) {
                if (!palettes.includes(b.palette)) throw new Error('Неизвестная палитра')
                settings.palette = b.palette
            }
            if (b?.memoryMB != null) {
                if (!Number.isInteger(b.memoryMB) || b.memoryMB < 2048 || b.memoryMB > maxMemory) throw new Error('Недопустимый объём памяти')
                settings.memoryMB = b.memoryMB
            }
            for (const key of ['fullscreen', 'autoConnect', 'remember']) if (typeof b[key] === 'boolean') settings[key] = b[key]
        }
        await saveSettings(); await saveSession(); return snapshot()
    })
    handler('directory', async () => {
        if (busy || runtime.game) throw new Error('Дождитесь завершения игры или установки')
        const result = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'], title: 'Родительская папка для отдельной сборки Humanitas' })
        if (!result.canceled) {
            settings.dataDirectory = path.join(result.filePaths[0], 'Humanitas')
            configureRuntime(); await installationStates()
            await saveSettings()
        }
        return snapshot()
    })
    handler('java', async () => {
        if (busy || runtime.game) throw new Error('Дождитесь завершения игры или установки')
        const result = await dialog.showOpenDialog(win, { properties: ['openFile'], title: 'Java 21 — java.exe' })
        if (!result.canceled) {
            if (!await runtime.java21(result.filePaths[0])) throw new Error('Нужна 64-битная Java 21')
            settings.javaPath = result.filePaths[0]; await saveSettings()
        }
        return snapshot()
    })
    handler('prepare', () => operation(() => runtime.prepare(settings)))
    handler('select-pack', async id => {
        if (busy || runtime.game) throw new Error('Завершите текущую игру или установку')
        if (!packs.some(p => p.id === id)) throw new Error('Сборка не найдена')
        settings.selectedPack = id; progress = null; status = { state: 'unconfigured' }
        configureRuntime(); await saveSettings(); emit(snapshot()); return snapshot()
    })
    handler('news-save', async input => {
        await identity()
        if (!accountInfo?.isAdmin) throw new Error('Доступно только администратору')
        const result = await getJSON(config.serviceURL + '/api/admin/news', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + session.accessToken }, body: JSON.stringify(input) })
        await checkServices(); return result
    })
    handler('news-delete', async id => {
        await identity()
        if (!accountInfo?.isAdmin) throw new Error('Доступно только администратору')
        await getJSON(config.serviceURL + '/api/admin/news/delete', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + session.accessToken }, body: JSON.stringify({ id }) })
        await checkServices()
    })
    handler('cancel', () => runtime.cancel())
    handler('launch', () => operation(async () => {
        await refresh()
        const child = await runtime.start(settings, session)
        const log = path.join(runtime.root, 'launcher-game.log')
        const secrets = [session.accessToken, session.clientToken]
        const write = b => fs.appendFile(log, redact(b, secrets)).catch(() => {})
        child.stdout?.on('data', write); child.stderr?.on('data', write)
        child.on('error', () => { runtime.game = null; emit({ gameRunning: false }) })
        child.on('close', code => {
            runtime.game = null
            progress = { stage: code === 0 ? 'Готово к игре' : 'Игра завершилась с ошибкой', detail: code === 0 ? 'Можно запустить снова' : 'Откройте папку сборки и launcher-game.log', percent: null, error: code !== 0 }
            emit({ gameRunning: false })
        })
        emit({ gameRunning: true }); return { started: true }
    }))
    handler('folder', async () => { await fs.mkdir(settings.dataDirectory, { recursive: true }); const exists = await fs.access(runtime.instance).then(() => true, () => false); await shell.openPath(exists ? runtime.instance : settings.dataDirectory) })
    handler('link', id => {
        const value = config.links?.[id]
        if (!value || !['discord', 'website'].includes(id) || new URL(value).protocol !== 'https:') throw new Error('Ссылка ещё не подключена')
        return shell.openExternal(value)
    })
    handler('window', action => {
        if (action === 'close') win.close()
        else if (action === 'minimize') win.minimize()
        else if (action === 'maximize') win.isMaximized() ? win.unmaximize() : win.maximize()
    })
    await win.loadFile(path.join(__dirname, 'ui', 'index.html'))
    checkServices()
    timer = setInterval(checkServices, 15000).unref()
}
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus() } })
if (single) app.whenReady().then(start).catch(e => { dialog.showErrorBox('Humanitas', e.message); app.exit(1) })
app.on('window-all-closed', () => { clearInterval(timer); app.quit() })
