const fs = require('node:fs/promises')
const { createReadStream } = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')

async function sha1(file) {
    const hash = crypto.createHash('sha1')
    for await (const chunk of createReadStream(file)) hash.update(chunk)
    return hash.digest('hex')
}

// Read a separately installed Modrinth cache; only verified copies enter our managed directory.
async function seedAssetsFromCache(version, destination, source, { signal, progress = () => {} } = {}) {
    const index = version.assetIndex
    if (!source || !index || !/^[a-f0-9]{40}$/i.test(index.sha1) || !/^[a-zA-Z0-9_.-]+$/.test(index.id)) return 0
    const indexPaths = [path.join(destination, 'assets', 'indexes', index.sha1 + '.json'), path.join(destination, 'assets', 'indexes', index.id + '.json'), path.join(source, 'indexes', index.id + '.json')]
    let bytes
    for (const indexPath of indexPaths) {
        try {
            const candidate = await fs.readFile(indexPath)
            if (crypto.createHash('sha1').update(candidate).digest('hex') === index.sha1.toLowerCase()) { bytes = candidate; break }
        } catch { /* Try the next verified source. */ }
    }
    if (!bytes && index.url && /^https:\/\//.test(index.url)) {
        try {
            const response = await fetch(index.url, { signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(20000)]) : AbortSignal.timeout(20000) })
            if (!response.ok || Number(response.headers.get('content-length') || 0) > 6 * 1024 * 1024) return 0
            const candidate = Buffer.from(await response.arrayBuffer())
            if (candidate.length <= 6 * 1024 * 1024 && crypto.createHash('sha1').update(candidate).digest('hex') === index.sha1.toLowerCase()) bytes = candidate
        } catch { if (signal?.aborted) signal.throwIfAborted() }
    }
    if (!bytes) return 0
    let objects
    try { objects = JSON.parse(bytes.toString('utf8')).objects } catch { return 0 }
    if (!objects || typeof objects !== 'object') return 0
    const unique = new Map()
    for (const item of Object.values(objects)) {
        if (item && /^[a-f0-9]{40}$/.test(item.hash) && Number.isSafeInteger(item.size) && item.size > 0) unique.set(item.hash, item.size)
    }
    const entries = [...unique], sourceRoot = path.join(source, 'objects'), targetRoot = path.join(destination, 'assets', 'objects')
    let cursor = 0, copied = 0, completed = 0
    async function worker() {
        while (cursor < entries.length) {
            signal?.throwIfAborted()
            const [hash, size] = entries[cursor++]
            const from = path.join(sourceRoot, hash.slice(0, 2), hash)
            const to = path.join(targetRoot, hash.slice(0, 2), hash)
            let temp
            try {
                const existing = await fs.stat(to).catch(() => null)
                if (existing?.isFile() && existing.size === size) continue
                const original = await fs.lstat(from).catch(() => null)
                if (!original?.isFile() || original.isSymbolicLink() || original.size !== size) continue
                await fs.mkdir(path.dirname(to), { recursive: true })
                temp = to + '.' + crypto.randomBytes(6).toString('hex') + '.part'
                await fs.copyFile(from, temp, fs.constants.COPYFILE_EXCL)
                if (await sha1(temp) !== hash) continue
                signal?.throwIfAborted()
                await fs.rename(temp, to)
                copied++
            } catch (error) { if (signal?.aborted) throw error }
            finally {
                if (temp) await fs.rm(temp, { force: true }).catch(() => {})
                completed++
                if (completed % 100 === 0) progress({ copied, completed, total: entries.length })
            }
        }
    }
    await Promise.all(Array.from({ length: Math.min(8, entries.length) }, worker))
    return copied
}
module.exports = { seedAssetsFromCache }
