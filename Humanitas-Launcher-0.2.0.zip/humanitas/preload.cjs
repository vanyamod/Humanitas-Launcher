const { contextBridge, ipcRenderer } = require('electron')
const call = (name, value) => ipcRenderer.invoke('humanitas:' + name, value)
contextBridge.exposeInMainWorld('humanitas', Object.freeze({
    state: () => call('state'), login: data => call('login', data), register: data => call('register', data),
    logout: () => call('logout'), settings: data => call('settings', data), chooseDirectory: () => call('directory'),
    chooseJava: () => call('java'), prepare: () => call('prepare'), launch: () => call('launch'), cancel: () => call('cancel'),
    openFolder: () => call('folder'), openLink: id => call('link', id), window: action => call('window', action),
    selectPack: id => call('select-pack', id), saveNews: input => call('news-save', input), deleteNews: id => call('news-delete', id),
    onUpdate: fn => { const listener = (_, value) => fn(value); ipcRenderer.on('humanitas:update', listener); return () => ipcRenderer.removeListener('humanitas:update', listener) }
}))
