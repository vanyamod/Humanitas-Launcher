const crypto = require('node:crypto')
const path = require('node:path')

function serviceURL(value, development = false) {
    const u = new URL(value)
    const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname)
    if (u.username || u.password || u.hash || u.search || (u.protocol !== 'https:' && !(development && loopback && u.protocol === 'http:'))) {
        throw new Error('Для сервиса нужен HTTPS. HTTP разрешён только локально в режиме разработки.')
    }
    return u.href.replace(/\/$/, '')
}

function safePath(root, relative) {
    if (typeof relative !== 'string' || !relative || relative.includes('\\') || relative.includes(':') || /[\x00-\x1f]/.test(relative)) throw new Error('Недопустимый путь')
    const parts = relative.split('/')
    if (parts.some(p => !p || p === '.' || p === '..' || /[. ]$/.test(p) || /^(con|prn|aux|nul|com\d|lpt\d)(\.|$)/i.test(p))) throw new Error('Недопустимый путь')
    const full = path.resolve(root, relative)
    if (!full.startsWith(path.resolve(root) + path.sep)) throw new Error('Путь вне каталога')
    return full
}

function downloadURL(value, development = false) {
    if (typeof value !== 'string' || value.length > 4096) throw new Error('Некорректный адрес файла')
    const u = new URL(value)
    const local = ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname)
    if (u.username || u.password || u.hash || (u.protocol !== 'https:' && !(development && local && u.protocol === 'http:'))) throw new Error('Файлы сборки должны загружаться по HTTPS')
    return u.href
}

function catalog(input, development = false) {
    if (!Array.isArray(input) || input.length > 30) throw new Error('Некорректный каталог сборок')
    const seen = new Set()
    return input.map(p => {
        if (!/^[a-z0-9][a-z0-9_-]{0,47}$/.test(p.id) || seen.has(p.id) || typeof p.name !== 'string' || !p.name.trim() || p.name.length > 80 || p.minecraft !== '1.21.1' || !/^21\.1\.\d+$/.test(p.neoforge)) throw new Error('Некорректная сборка в каталоге')
        seen.add(p.id)
        if (p.serverAddress && !/^(\[[a-f\d:]+\]|[a-z\d.-]+)(?::\d{1,5})?$/i.test(p.serverAddress)) throw new Error('Некорректный адрес сервера сборки')
        return { id: p.id, name: p.name.trim(), description: String(p.description || '').slice(0, 500), minecraft: p.minecraft, neoforge: p.neoforge,
            manifestURL: p.manifestURL ? downloadURL(p.manifestURL, development) : null,
            blobBaseURL: p.blobBaseURL ? downloadURL(p.blobBaseURL, development).replace(/\/$/, '') : null,
            serverAddress: p.serverAddress || null }
    })
}

function checkManifest(envelope, publicKey, { development = false } = {}) {
    if (!publicKey || typeof envelope?.payload !== 'string' || typeof envelope.signature !== 'string') throw new Error('Манифест не подписан')
    const bytes = Buffer.from(envelope.payload, 'base64')
    if (!crypto.verify(null, bytes, publicKey, Buffer.from(envelope.signature, 'base64'))) throw new Error('Подпись сборки не совпадает')
    const m = JSON.parse(bytes)
    m.id ||= 'humanitas'
    if (!/^[a-z0-9][a-z0-9_-]{0,47}$/.test(m.id)) throw new Error('Некорректный идентификатор сборки')
    if (m.blobBaseURL) m.blobBaseURL = downloadURL(m.blobBaseURL, development).replace(/\/$/, '')
    if (m.schema !== 1 || m.minecraft !== '1.21.1' || !/^21\.1\.\d+$/.test(m.neoforge) || !Array.isArray(m.files) || m.files.length > 20000) throw new Error('Неподдерживаемый манифест')
    const seen = new Set()
    for (const f of m.files) {
        safePath('instance', f.path)
        if (!/^(mods|config|defaultconfigs|resourcepacks|shaderpacks|kubejs)\//.test(f.path) || !/^[a-f0-9]{64}$/.test(f.sha256) || !Number.isSafeInteger(f.size) || f.size < 0 || f.size > 1024 ** 3 || !['managed', 'seed'].includes(f.mode)) throw new Error('Недопустимый файл сборки')
        const key = f.path.toLowerCase()
        if (seen.has(key)) throw new Error('Повтор пути в сборке')
        seen.add(key)
        if (f.url) f.url = downloadURL(f.url, development)
    }
    if (m.agent && (!/^[a-f0-9]{64}$/.test(m.agent.sha256) || !Number.isSafeInteger(m.agent.size) || m.agent.size < 1 || m.agent.size > 10 * 1024 ** 2)) throw new Error('Недопустимый агент авторизации')
    if (m.agent?.url) m.agent.url = downloadURL(m.agent.url, development)
    return m
}

function offlineUUID(name) {
    const b = crypto.createHash('md5').update('OfflinePlayer:' + name).digest()
    b[6] = (b[6] & 15) | 48
    b[8] = (b[8] & 63) | 128
    return b.toString('hex')
}

function redact(text, secrets = []) {
    let result = String(text)
    for (const secret of secrets) if (secret) result = result.split(secret).join('[скрыто]')
    return result.replace(/(--accessToken\s+|"?(?:accessToken|clientToken|password)"?\s*[:=]\s*"?)[^\s",}]+/gi, '$1[скрыто]')
}

module.exports = { serviceURL, downloadURL, catalog, safePath, checkManifest, offlineUUID, redact }
