const crypto = require('node:crypto')

function text(value, maximum, required = false) {
    if (typeof value !== 'string' || value.length > maximum || (required && !value.trim())) throw new Error('Check the title and text')
    return value.trim()
}
class Content {
    constructor(store) {
        this.db = store.db
        this.db.exec(`CREATE TABLE IF NOT EXISTS news (id TEXT PRIMARY KEY, channel TEXT NOT NULL, source TEXT NOT NULL, source_id TEXT UNIQUE, title TEXT NOT NULL, body TEXT NOT NULL, author TEXT NOT NULL, state_name TEXT NOT NULL DEFAULT '', published INTEGER NOT NULL, pinned INTEGER NOT NULL DEFAULT 0);`)
    }
    list(channel) {
        return this.db.prepare('SELECT id,channel,source,title,body AS text,author,state_name AS stateName,published,pinned FROM news WHERE channel=? ORDER BY pinned DESC,published DESC,id DESC LIMIT 100').all(channel).map(n => ({ ...n, pinned: !!n.pinned }))
    }
    post(user, input) {
        const title = text(input.title, 160, true), body = text(input.text, 20000, true)
        const id = input.id || crypto.randomUUID()
        if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error('Unknown publication')
        if (input.id) {
            const old = this.db.prepare('SELECT source FROM news WHERE id=?').get(id)
            if (!old || old.source !== 'admin') throw new Error('This publication cannot be edited')
            this.db.prepare('UPDATE news SET title=?,body=?,pinned=? WHERE id=?').run(title, body, input.pinned === true ? 1 : 0, id)
        } else this.db.prepare('INSERT INTO news (id,channel,source,title,body,author,published,pinned) VALUES (?,\'updates\',\'admin\',?,?,?,?,?)').run(id, title, body, user.name, Date.now(), input.pinned === true ? 1 : 0)
        return id
    }
    remove(id) {
        if (typeof id !== 'string') throw new Error('Unknown publication')
        const result = this.db.prepare('DELETE FROM news WHERE id=? AND source=\'admin\'').run(id)
        if (!result.changes) throw new Error('Publication not found')
    }
    syncCivitas(pack, items) {
        if (!/^[a-z0-9][a-z0-9_-]{0,47}$/.test(pack) || !Array.isArray(items) || items.length > 100) throw new Error('Invalid Civitas news feed')
        const rows = items.map(n => {
            if (!Number.isSafeInteger(n.id) || n.id < 0 || !Number.isSafeInteger(n.published) || n.published < 0) throw new Error('Invalid Civitas news item')
            return { id: `${pack}:${n.id}`, title: text(n.title, 160, true), body: text(n.text, 20000, true), author: text(n.author || '', 64), state: text(n.stateName || '', 120), published: n.published }
        })
        this.db.exec('BEGIN IMMEDIATE')
        try {
            this.db.prepare('DELETE FROM news WHERE source=\'civitas\' AND source_id GLOB ?').run(pack + ':*')
            const put = this.db.prepare('INSERT INTO news (id,channel,source,source_id,title,body,author,state_name,published) VALUES (?,\'civitas\',\'civitas\',?,?,?,?,?,?)')
            for (const n of rows) put.run('civitas-' + n.id, n.id, n.title, n.body, n.author, n.state, n.published)
            this.db.exec('COMMIT')
        } catch (e) { this.db.exec('ROLLBACK'); throw e }
        return rows.length
    }
}
module.exports = { Content }
