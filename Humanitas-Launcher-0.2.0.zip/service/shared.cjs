const crypto = require('node:crypto')
function serviceURL(value, development = false) {
    const u = new URL(value)
    const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname)
    if (u.username || u.password || u.hash || u.search || (u.protocol !== 'https:' && !(development && loopback && u.protocol === 'http:'))) {
        throw new Error('The service requires HTTPS; HTTP is allowed only for local development.')
    }
    return u.href.replace(/\/$/, '')
}
function offlineUUID(name) {
    const b = crypto.createHash('md5').update('OfflinePlayer:' + name).digest()
    b[6] = (b[6] & 15) | 48
    b[8] = (b[8] & 63) | 128
    return b.toString('hex')
}
module.exports = { serviceURL, offlineUUID }
