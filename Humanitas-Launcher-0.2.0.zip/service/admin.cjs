const path = require('node:path')
const { Store } = require('./store.cjs')
const store = new Store(process.env.HUMANITAS_AUTH_DATA || path.join(__dirname, 'data'))
try {
    const [command, name] = process.argv.slice(2)
    if (command === 'invite' && name) console.log(store.invite(24, name))
    else if (['block', 'unblock', 'logout', 'admin', 'unadmin'].includes(command) && name) {
        const user = store.db.prepare('SELECT id FROM users WHERE name=?').get(name)
        if (!user) throw new Error('Player not found')
        if (['admin', 'unadmin'].includes(command)) store.db.prepare('UPDATE users SET is_admin=? WHERE id=?').run(command === 'admin' ? 1 : 0, user.id)
        else if (command !== 'logout') store.db.prepare('UPDATE users SET blocked=? WHERE id=?').run(command === 'block' ? 1 : 0, user.id)
        store.db.prepare('DELETE FROM tokens WHERE uid=?').run(user.id)
        console.log('Done')
    } else if (command === 'bridge-key') console.log(require('node:crypto').randomBytes(32).toString('hex'))
    else throw new Error('Commands: invite NAME | admin NAME | unadmin NAME | block NAME | unblock NAME | logout NAME | bridge-key')
} finally { store.close() }
