const http = require('node:http')
const https = require('node:https')
const fs = require('node:fs/promises')
const path = require('node:path')
const { createReadStream } = require('node:fs')
const { Store } = require('./store.cjs')
const { serviceURL } = require('./shared.cjs')
const { Content } = require('./content.cjs')
const crypto = require('node:crypto')

async function readBody(req, maximum = 65536) {
    if (!req.headers['content-type']?.startsWith('application/json')) throw Object.assign(new Error('JSON is required'), { status: 415 })
    let bytes = 0
    const chunks = []
    for await (const b of req) {
        bytes += b.length
        if (bytes > maximum) throw Object.assign(new Error('Request is too large'), { status: 413 })
        chunks.push(b)
    }
    try { return JSON.parse(Buffer.concat(chunks).toString('utf8')) } catch { throw new Error('Invalid JSON') }
}

function createService({ directory, release, publicURL = 'http://127.0.0.1:18740', development = false, trustLoopbackProxy = false, bridgeToken = process.env.CIVITAS_BRIDGE_TOKEN, tls = null }) {
    const base = serviceURL(publicURL, development)
    const store = new Store(directory)
    const content = new Content(store)
    const bearerUser = req => store.session(req.headers.authorization?.replace(/^Bearer /, ''))
    const joins = new Map()
    let passwordsInFlight = 0
    async function passwordWork(work) {
        if (passwordsInFlight >= 4) throw Object.assign(new Error('Service is busy. Please try again shortly.'), { status: 429 })
        passwordsInFlight++
        try { return await work() } finally { passwordsInFlight-- }
    }
    const cleanup = setInterval(() => {
        store.prune()
        for (const [key, join] of joins) if (join.expires < Date.now()) joins.delete(key)
    }, 60000).unref()
    const handler = async (req, res) => {
        const send = (status, data) => {
            res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' })
            res.end(data == null ? undefined : JSON.stringify(data))
        }
        try {
            const u = new URL(req.url, 'http://localhost')
            let ip = req.socket.remoteAddress
            if (trustLoopbackProxy && ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(ip)) {
                // Reverse proxy must REPLACE this header, never append user-supplied text.
                ip = req.headers['x-real-ip'] || ip
            }
            if (req.method === 'GET' && u.pathname === '/health') return send(200, { status: 'ok', name: 'Humanitas Accounts' })
            if (req.method === 'GET' && u.pathname === '/yggdrasil/') return send(200, {
                meta: { serverName: 'Humanitas', implementationName: 'Humanitas Accounts', implementationVersion: '0.2.0', 'feature.non_email_login': true, 'feature.no_mojang_namespace': true, 'feature.enable_profile_key': false },
                skinDomains: [], signaturePublickey: store.publicKey
            })
            if (req.method === 'GET' && u.pathname === '/api/news') {
                return send(200, { updates: content.list('updates'), civitas: content.list('civitas') })
            }
            if (req.method === 'GET' && u.pathname === '/api/me') {
                const user = bearerUser(req)
                if (!user) return send(403, { message: 'Please sign in' })
                return send(200, { id: user.id, name: user.name, isAdmin: !!user.is_admin })
            }
            if (req.method === 'GET' && u.pathname === '/api/catalog') {
                const file = await fs.readFile(path.join(release, 'catalog.json'), 'utf8').then(JSON.parse).catch(e => { if (e.code === 'ENOENT') return null; throw e })
                return send(200, file || [{ id: 'humanitas', name: 'Humanitas', description: '', minecraft: '1.21.1', neoforge: '21.1.250', manifestURL: base + '/release/manifest.json', blobBaseURL: base + '/release', serverAddress: process.env.MINECRAFT_SERVER || null }])
            }
            if (req.method === 'GET' && (u.pathname === '/release/manifest.json' || /^\/release\/packs\/[a-z0-9_-]{1,48}\/manifest.json$/.test(u.pathname) || /^\/release\/blobs\/[a-f0-9]{64}$/.test(u.pathname))) {
                const file = path.join(release, u.pathname.slice('/release/'.length))
                const stat = await fs.stat(file).catch(() => null)
                if (!stat?.isFile()) return send(404, { message: 'The pack file has not been published' })
                res.writeHead(200, { 'Content-Type': u.pathname.endsWith('.json') ? 'application/json' : 'application/octet-stream', 'Content-Length': stat.size, 'Cache-Control': u.pathname.includes('/blobs/') ? 'public,max-age=31536000,immutable' : 'no-cache', 'X-Content-Type-Options': 'nosniff' })
                const stream = createReadStream(file)
                stream.on('error', () => res.destroy())
                stream.pipe(res)
                return
            }
            if (req.method === 'GET' && u.pathname.endsWith('/hasJoined')) {
                const key = u.searchParams.get('serverId') + ':' + u.searchParams.get('username')?.toLowerCase()
                const join = joins.get(key)
                if (!join || join.expires < Date.now() || (u.searchParams.has('ip') && u.searchParams.get('ip') !== join.ip)) return send(204)
                // Re-check the token: block, logout and rotation also revoke a pending join.
                const user = store.session(join.token)
                if (!user) return send(204)
                joins.delete(key)
                return send(200, store.profile(user))
            }
            if (req.method === 'GET' && /^\/yggdrasil\/sessionserver\/session\/minecraft\/profile\/[a-f0-9]{32}$/.test(u.pathname)) {
                const user = store.user(u.pathname.split('/').pop())
                return user ? send(200, store.profile(user, u.searchParams.get('unsigned') === 'false')) : send(204)
            }
            if (req.method !== 'POST') return send(404, { message: 'Not found' })
            if (u.pathname === '/api/civitas/sync') {
                const token = req.headers.authorization?.replace(/^Bearer /, '')
                if (!bridgeToken || bridgeToken.length < 32 || typeof token !== 'string' || !crypto.timingSafeEqual(crypto.createHash('sha256').update(token).digest(), crypto.createHash('sha256').update(bridgeToken).digest())) return send(403, { message: 'Synchronization access denied' })
                store.limit('bridge:' + ip, 20, 60000)
                const input = await readBody(req, 4 * 1024 ** 2)
                return send(200, { count: content.syncCivitas(input.pack, input.items) })
            }
            if (u.pathname.startsWith('/api/admin/')) {
                const user = bearerUser(req)
                if (!user?.is_admin) return send(403, { message: 'Administrator access required' })
                store.limit('publish:' + user.id, 30, 60000)
                const input = await readBody(req)
                if (u.pathname === '/api/admin/news') return send(200, { id: content.post(user, input) })
                if (u.pathname === '/api/admin/news/delete') { content.remove(input.id); return send(204) }
                return send(404, { message: 'Not found' })
            }
            const b = await readBody(req)
            if (!b || typeof b !== 'object') throw new Error('Invalid request')
            const route = u.pathname.replace('/yggdrasil', '')
            if (route === '/api/profiles/minecraft') {
                if (!Array.isArray(b) || b.length > 100 || b.some(n => typeof n !== 'string' || !/^[A-Za-z0-9_]{3,16}$/.test(n))) throw new Error('Invalid profile list')
                store.limit('profiles:' + ip, 120, 60000)
                const lookup = store.db.prepare('SELECT id,name FROM users WHERE name=? AND blocked=0')
                return send(200, b.map(n => lookup.get(n)).filter(Boolean))
            }
            if (route === '/api/register') {
                store.limit('register-ip:' + ip, 8, 3600000)
                await passwordWork(() => store.register(b.username, b.password, b.invite))
                return send(201, { message: 'Account created. You can now sign in.' })
            }
            if (route === '/authserver/authenticate' || route === '/authserver/signout') {
                store.limit('login-ip:' + ip, 40)
                store.limit('login-user:' + String(b.username).toLowerCase().slice(0, 128), 10)
                const user = await passwordWork(() => store.password(b.username, b.password))
                if (!user) throw Object.assign(new Error('Incorrect username or password'), { status: 403 })
                if (route.endsWith('/signout')) {
                    store.db.prepare('DELETE FROM tokens WHERE uid=?').run(user.id)
                    return send(204)
                }
                return send(200, store.issue(user, b.clientToken || require('node:crypto').randomUUID()))
            }
            const token = b.accessToken
            const user = store.session(token)
            if (!user || (b.clientToken != null && b.clientToken !== user.client)) throw Object.assign(new Error('Session expired. Please sign in again.'), { status: 403 })
            if (route === '/authserver/validate') return send(204)
            if (route === '/authserver/invalidate') { store.revoke(token); return send(204) }
            if (route === '/authserver/refresh') {
                if (b.selectedProfile && b.selectedProfile.id !== user.id) throw new Error('Profile mismatch')
                const next = store.issue(user, user.client)
                store.revoke(token)
                return send(200, next)
            }
            if (route === '/sessionserver/session/minecraft/join') {
                if (b.selectedProfile !== user.id || typeof b.serverId !== 'string' || !/^-?[0-9a-f]{1,40}$/.test(b.serverId)) throw new Error('Invalid game session')
                store.limit('join:' + user.id, 30, 60000)
                const key = b.serverId + ':' + user.name.toLowerCase()
                joins.set(key, { token, ip, expires: Date.now() + 30000 })
                return send(204)
            }
            return send(404, { message: 'Not found' })
        } catch (e) {
            if (!res.headersSent) {
                const status = e.status || 400
                // No database details, passwords, tokens or request bodies in logs/responses.
                const message = /SQLITE|database|constraint/i.test(e.message) ? 'Could not process the request' : e.message
                send(status, { error: status === 403 ? 'ForbiddenOperationException' : 'IllegalArgumentException', errorMessage: message, message })
            } else res.destroy()
        }
    }
    const server = tls ? https.createServer(tls, handler) : http.createServer(handler)
    server.requestTimeout = 15000
    server.headersTimeout = 10000
    server.on('close', () => { clearInterval(cleanup); store.close() })
    return { server, store, content, base }
}

if (require.main === module) {
    const dev = process.env.HUMANITAS_DEVELOPMENT === '1'
    const port = Number(process.env.PORT || 18740)
    const publicURL = process.env.PUBLIC_URL || (dev ? `http://127.0.0.1:${port}` : '')
    if (!publicURL) throw new Error('Set PUBLIC_URL to the public HTTPS address')
    const tlsKey = process.env.HUMANITAS_TLS_KEY
    const tlsCert = process.env.HUMANITAS_TLS_CERT
    if (!!tlsKey !== !!tlsCert) throw new Error('Set both HUMANITAS_TLS_KEY and HUMANITAS_TLS_CERT')
    const tls = tlsKey ? { key: require('node:fs').readFileSync(tlsKey), cert: require('node:fs').readFileSync(tlsCert), minVersion: 'TLSv1.2' } : null
    const listenHost = process.env.HUMANITAS_LISTEN || '127.0.0.1'
    if (!dev && listenHost !== '127.0.0.1' && !tls) throw new Error('The public service must use TLS')
    const { server } = createService({ tls, directory: process.env.HUMANITAS_AUTH_DATA || path.join(__dirname, 'data'), release: process.env.HUMANITAS_RELEASE || path.join(__dirname, '..', 'release', 'public'), publicURL, development: dev, trustLoopbackProxy: process.env.TRUST_LOOPBACK_PROXY === '1' })
    server.listen(port, listenHost, () => console.log(`Humanitas Accounts: ${listenHost}:${port}`))
    for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => server.close())
}
module.exports = { createService }
