const { DatabaseSync } = require('node:sqlite')
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const { promisify } = require('node:util')
const { offlineUUID } = require('./shared.cjs')
const scrypt = promisify(crypto.scrypt)
const digest = value => crypto.createHash('sha256').update(value).digest('hex')

class Store {
    constructor(directory) {
        fs.mkdirSync(directory, { recursive: true, mode: 0o700 })
        this.db = new DatabaseSync(path.join(directory, 'accounts.sqlite'))
        this.db.exec(`PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE, salt TEXT NOT NULL, hash TEXT NOT NULL, blocked INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS tokens (hash TEXT PRIMARY KEY, uid TEXT NOT NULL, client TEXT NOT NULL, expires INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS invites (hash TEXT PRIMARY KEY, expires INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS attempts (key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires INTEGER NOT NULL);`)
        if (!this.db.prepare('PRAGMA table_info(invites)').all().some(c => c.name === 'name')) this.db.exec('ALTER TABLE invites ADD COLUMN name TEXT')
        if (!this.db.prepare('PRAGMA table_info(users)').all().some(c => c.name === 'is_admin')) this.db.exec('ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0')
        const privateFile = path.join(directory, 'profile-private.pem')
        if (!fs.existsSync(privateFile)) {
            const keys = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 })
            fs.writeFileSync(privateFile, keys.privateKey.export({ type: 'pkcs8', format: 'pem' }), { flag: 'wx', mode: 0o600 })
        }
        this.key = fs.readFileSync(privateFile)
        this.publicKey = crypto.createPublicKey(this.key).export({ type: 'spki', format: 'pem' })
        this.dummySalt = crypto.randomBytes(16).toString('hex')
        this.prune()
    }
    prune() {
        const now = Date.now()
        for (const table of ['tokens', 'attempts', 'invites']) this.db.prepare(`DELETE FROM ${table} WHERE expires < ?`).run(now)
    }
    limit(key, max = 12, milliseconds = 15 * 60000) {
        const now = Date.now()
        const row = this.db.prepare('SELECT * FROM attempts WHERE key=?').get(key)
        if (row?.expires > now && row.count >= max) throw Object.assign(new Error('Too many attempts. Please try again later.'), { status: 429 })
        this.db.prepare('INSERT INTO attempts VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN expires<? THEN 1 ELSE count+1 END, expires=CASE WHEN expires<? THEN excluded.expires ELSE expires END').run(key, now + milliseconds, now, now)
    }
    invite(hours = 24, name = null) {
        if (name && !/^[A-Za-z0-9_]{3,16}$/.test(name)) throw new Error('Invalid invitation username')
        const value = crypto.randomBytes(18).toString('base64url')
        this.db.prepare('INSERT INTO invites (hash,expires,used,name) VALUES (?,?,0,?)').run(digest(value), Date.now() + hours * 3600000, name)
        return value
    }
    async register(name, password, invite) {
        if (typeof name !== 'string' || !/^[A-Za-z0-9_]{3,16}$/.test(name)) throw new Error('Username must contain 3–16 letters, numbers or underscores')
        if (typeof password !== 'string' || password.length < 12 || password.length > 128) throw new Error('Password must contain 12–128 characters')
        if (typeof invite !== 'string' || invite.length > 128) throw new Error('A valid invitation code is required')
        const salt = crypto.randomBytes(16).toString('hex')
        const hash = (await scrypt(password, salt, 64, { N: 32768, maxmem: 64 * 1024 ** 2 })).toString('hex')
        this.db.exec('BEGIN IMMEDIATE')
        try {
            const changed = this.db.prepare('UPDATE invites SET used=1 WHERE hash=? AND used=0 AND expires>? AND (name IS NULL OR name=?)').run(digest(invite), Date.now(), name)
            if (!changed.changes) throw new Error('The invitation code is invalid or has already been used')
            const id = offlineUUID(name)
            this.db.prepare('INSERT INTO users (id,name,salt,hash) VALUES (?,?,?,?)').run(id, name, salt, hash)
            this.db.exec('COMMIT')
            return { id, name }
        } catch (e) {
            this.db.exec('ROLLBACK')
            if (e.code?.includes('SQLITE') || e.message.includes('UNIQUE')) throw new Error('This username is already taken')
            throw e
        }
    }
    async password(name, password) {
        if (typeof name !== 'string' || name.length > 128 || typeof password !== 'string' || password.length > 128) return null
        const user = this.db.prepare('SELECT * FROM users WHERE name=?').get(name)
        const hash = await scrypt(password, user?.salt || this.dummySalt, 64, { N: 32768, maxmem: 64 * 1024 ** 2 })
        return user && !user.blocked && crypto.timingSafeEqual(hash, Buffer.from(user.hash, 'hex')) ? user : null
    }
    issue(user, client) {
        if (typeof client !== 'string' || client.length < 1 || client.length > 128) throw new Error('Invalid client')
        const accessToken = crypto.randomBytes(32).toString('hex')
        this.db.prepare('INSERT INTO tokens VALUES (?,?,?,?)').run(digest(accessToken), user.id, client, Date.now() + 7 * 86400000)
        // Bound concurrent sessions per account; no unbounded token table growth.
        this.db.prepare('DELETE FROM tokens WHERE uid=? AND hash NOT IN (SELECT hash FROM tokens WHERE uid=? ORDER BY expires DESC LIMIT 8)').run(user.id, user.id)
        return { accessToken, clientToken: client, selectedProfile: { id: user.id, name: user.name }, availableProfiles: [{ id: user.id, name: user.name }], user: { id: user.id, properties: [] } }
    }
    session(token) {
        if (typeof token !== 'string' || token.length !== 64) return null
        return this.db.prepare('SELECT u.*,t.client FROM tokens t JOIN users u ON u.id=t.uid WHERE t.hash=? AND t.expires>? AND u.blocked=0').get(digest(token), Date.now()) || null
    }
    revoke(token) { if (typeof token === 'string') this.db.prepare('DELETE FROM tokens WHERE hash=?').run(digest(token)) }
    user(id) { return this.db.prepare('SELECT id,name FROM users WHERE id=? AND blocked=0').get(id) }
    profile(user, signed = true) {
        const value = Buffer.from(JSON.stringify({ timestamp: Date.now(), profileId: user.id, profileName: user.name, textures: {} })).toString('base64')
        const property = { name: 'textures', value }
        if (signed) property.signature = crypto.sign('RSA-SHA1', Buffer.from(value), this.key).toString('base64')
        return { id: user.id, name: user.name, properties: [property] }
    }
    close() { this.db.close() }
}
module.exports = { Store, digest }
