import js from '@eslint/js'
import globals from 'globals'
export default [
    { ignores: ['node_modules/**', 'dist/**', 'build/**', 'app/**', 'index.js'] },
    js.configs.recommended,
    { files: ['**/*.cjs'], languageOptions: { globals: globals.node }, rules: { 'no-control-regex': 'off', 'no-unused-vars': ['error', { caughtErrors: 'none' }] } },
    { files: ['humanitas/ui/*.js'], languageOptions: { globals: globals.browser } },
    { files: ['tools/qa-ui.cjs', 'tools/qa-packed.cjs'], languageOptions: { globals: { window: 'readonly', document: 'readonly' } } }
]
