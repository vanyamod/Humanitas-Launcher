const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const crypto = require('node:crypto')
const { seedAssetsFromCache } = require('../humanitas/asset-cache.cjs')
const { Runtime, networkRetryable } = require('../humanitas/runtime.cjs')
const hash = b => crypto.createHash('sha1').update(b).digest('hex')

test('local asset cache copies verified resources and leaves invalid source and existing files untouched', async () => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), 'humanitas-cache-'))
    try {
        const src = path.join(root,'src'), dst = path.join(root,'dst')
        const good=Buffer.from('verified content'), bad=Buffer.from('invalid bytes!!!'), existing=Buffer.from('keep this file')
        const gh=hash(good), bh=hash(Buffer.from('different bytes!')), eh=hash(existing)
        const index=Buffer.from(JSON.stringify({objects:{a:{hash:gh,size:good.length},b:{hash:bh,size:bad.length},c:{hash:eh,size:existing.length}}}))
        await fs.mkdir(path.join(src,'indexes'),{recursive:true}); await fs.writeFile(path.join(src,'indexes','17.json'),index)
        for(const [h,bytes] of [[gh,good],[bh,bad],[eh,existing]]) { await fs.mkdir(path.join(src,'objects',h.slice(0,2)),{recursive:true}); await fs.writeFile(path.join(src,'objects',h.slice(0,2),h),bytes) }
        const target=h=>path.join(dst,'assets','objects',h.slice(0,2),h)
        await fs.mkdir(path.dirname(target(eh)),{recursive:true}); await fs.writeFile(target(eh),existing)
        assert.equal(await seedAssetsFromCache({assetIndex:{id:'17',sha1:hash(index)}},dst,src),1)
        assert.deepEqual(await fs.readFile(target(gh)),good)
        assert.deepEqual(await fs.readFile(target(eh)),existing)
        await assert.rejects(fs.stat(target(bh)),{code:'ENOENT'})
        assert.equal(await seedAssetsFromCache({assetIndex:{id:'17',sha1:'0'.repeat(40)}},dst,src),0)
    } finally { await fs.rm(root,{recursive:true,force:true}) }
})

test('retry only transient failures and companion checksum errors', async () => {
    const timeout=Object.assign(new Error('timeout'),{code:'UND_ERR_CONNECT_TIMEOUT',destination:'a'})
    const invalid=Object.assign(new Error('checksum'),{phase:'validate',destination:'a'})
    const full=Object.assign(new Error('disk full'),{code:'ENOSPC'})
    assert.equal(networkRetryable(new AggregateError([timeout,invalid])),true)
    assert.equal(networkRetryable(new AggregateError([timeout,full])),false)
    assert.equal(networkRetryable(new AggregateError([invalid])),false)
    const rt=new Runtime({},os.tmpdir(),()=>{})
    let count=0
    rt.runTask=async()=>{count++;if(count===1)throw new AggregateError([timeout,invalid]);return 'ok'}
    assert.equal(await rt.runTaskWithRetry(()=>({}),'test',new AbortController().signal),'ok')
    assert.equal(count,2)
})
