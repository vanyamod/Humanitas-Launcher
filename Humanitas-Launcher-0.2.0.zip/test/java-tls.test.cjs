const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const https = require('node:https')
const { execFile, execFileSync } = require('node:child_process')
const { promisify } = require('node:util')
const { Runtime } = require('../humanitas/runtime.cjs')
const exec = promisify(execFile)

test('game Java trusts the pinned host without changing its original truststore', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'humanitas-java-tls-'))
    const openssl = process.platform === 'win32' ? 'C:/Program Files/Git/usr/bin/openssl.exe' : 'openssl'
    const java = process.platform === 'win32' ? 'C:/Program Files/Java/jdk-21/bin/java.exe' : process.env.JAVA_HOME + '/bin/java'
    let server
    try {
        const key = path.join(dir, 'server.key'), cert = path.join(dir, 'server.pem')
        execFileSync(openssl, ['req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=127.0.0.1','-addext','subjectAltName=IP:127.0.0.1','-keyout',key,'-out',cert], { stdio:'ignore' })
        const pem = await fs.readFile(cert, 'utf8')
        server = https.createServer({ key: await fs.readFile(key), cert: pem }, (_req, res) => res.end('ok'))
        await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
        const program = path.join(dir, 'Check.java')
        await fs.writeFile(program, 'import java.net.*; public class Check { public static void main(String[] a) throws Exception { try(var in = new URL(a[0]).openStream()){System.out.print(new String(in.readAllBytes()));} } }')
        const rt = new Runtime({}, dir, () => {})
        const store = await rt.createTrustStore(java, pem)
        const url = 'https://127.0.0.1:' + server.address().port
        await assert.rejects(exec(java, [program, url], { timeout: 15000 }))
        const result = await exec(java, ['-Djavax.net.ssl.trustStore=' + store, '-Djavax.net.ssl.trustStorePassword=changeit', program, url], { timeout: 15000 })
        assert.equal(result.stdout, 'ok')
        assert.equal(await rt.createTrustStore(java, pem), store)
    } finally {
        if (server) await new Promise(resolve => server.close(resolve))
        await fs.rm(dir, { recursive:true, force:true })
    }
})
