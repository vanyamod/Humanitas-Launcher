const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const crypto = require('node:crypto')
const http = require('node:http')
const { safePath, serviceURL, checkManifest, redact } = require('../humanitas/shared.cjs')
const { downloadVerified, syncPack } = require('../humanitas/files.cjs')
const { collect } = require('../tools/pack.cjs')
for (const name of ['../saves/world.dat', '/absolute', 'mods/../../evil', 'mods/con.jar', 'mods/a:stream', 'mods/a\\b', 'mods/x./a', 'mods//a', 'mods/\u0000']) {
    test('reject unsafe path ' + JSON.stringify(name), () => assert.throws(() => safePath('instance', name)))
}
test('production endpoints cannot downgrade to insecure HTTP', () => {
    assert.throws(() => serviceURL('http://example.com', true))
    assert.throws(() => serviceURL('http://127.0.0.1'))
    assert.equal(serviceURL('http://127.0.0.1:18740/', true), 'http://127.0.0.1:18740')
    assert.throws(() => serviceURL('https://user:password@example.com'))
})
test('manifest rejects tampering and protected directories even with valid signatures', () => {
    const keys = crypto.generateKeyPairSync('ed25519')
    const m = { schema: 1, minecraft: '1.21.1', neoforge: '21.1.250', files: [{ path: 'mods/test.jar', sha256: 'a'.repeat(64), size: 4, mode: 'managed' }] }
    const wrap = value => { const b = Buffer.from(JSON.stringify(value)); return { payload: b.toString('base64'), signature: crypto.sign(null, b, keys.privateKey).toString('base64') } }
    const envelope = wrap(m)
    assert.equal(checkManifest(envelope, keys.publicKey).files.length, 1)
    assert.throws(() => checkManifest({ ...envelope, payload: Buffer.from('{}').toString('base64') }, keys.publicKey))
    assert.throws(() => checkManifest(wrap({ ...m, files: [{ ...m.files[0], path: 'saves/world.dat' }] }), keys.publicKey))
    assert.throws(() => checkManifest(wrap({ ...m, files: [m.files[0], { ...m.files[0], path: 'mods/TEST.jar' }] }), keys.publicKey))
    assert.equal(redact('token SECRET --accessToken abc', ['SECRET']).includes('SECRET'), false)
})
test('file repair preserves saves/configs and backs up extra mods; broken downloads cannot replace files', async t => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), 'humanitas-files-'))
    const bytes = Buffer.from('test jar data'), hash = crypto.createHash('sha256').update(bytes).digest('hex')
    const server = http.createServer((req, res) => {
        if (req.url === '/html') { res.writeHead(200, { 'Content-Type': 'text/html' }); res.end('<html>confirm download</html>'); return }
        if (req.url === '/redirect') { res.writeHead(302, { Location: '/file' }); res.end(); return }
        res.end(req.url === '/bad' ? 'bad' : bytes)
    })
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
    t.after(async () => { await new Promise(resolve => server.close(resolve)); await fs.rm(root, { recursive: true, force: true }) })
    const base = 'http://127.0.0.1:' + server.address().port
    await fs.mkdir(path.join(root, 'saves')); await fs.writeFile(path.join(root, 'saves', 'world.dat'), 'personal world')
    await fs.mkdir(path.join(root, 'mods')); await fs.writeFile(path.join(root, 'mods', 'old.jar'), 'old')
    await fs.mkdir(path.join(root, 'config')); await fs.writeFile(path.join(root, 'config', 'client.toml'), 'my config')
    const info = { sha256: hash, size: bytes.length }
    await syncPack({ files: [{ path: 'mods/new.jar', ...info, mode: 'managed' }, { path: 'config/client.toml', ...info, mode: 'seed' }] }, root, base)
    assert.equal(await fs.readFile(path.join(root, 'mods', 'new.jar'), 'utf8'), bytes.toString())
    assert.equal(await fs.readFile(path.join(root, 'saves', 'world.dat'), 'utf8'), 'personal world')
    assert.equal(await fs.readFile(path.join(root, 'config', 'client.toml'), 'utf8'), 'my config')
    const [backup] = await fs.readdir(path.join(root, 'backups'))
    assert.equal(await fs.readFile(path.join(root, 'backups', backup, 'old.jar'), 'utf8'), 'old')
    await assert.rejects(downloadVerified(base + '/bad', path.join(root, 'mods', 'new.jar'), info))
    await assert.rejects(downloadVerified(base + '/html', path.join(root, 'mods', 'new.jar'), info), /прямая ссылка/)
    await assert.rejects(downloadVerified(base + '/redirect', path.join(root, 'mods', 'new.jar'), info))
    await assert.rejects(downloadVerified(base + '/redirect', path.join(root, 'mods', 'new.jar'), info, undefined, undefined, { allowHTTPSRedirects: true }))
    assert.equal(await fs.readFile(path.join(root, 'mods', 'new.jar'), 'utf8'), bytes.toString())
    assert.deepEqual((await fs.readdir(path.join(root, 'mods'))).filter(f => f.endsWith('.part')), [])
    await fs.writeFile(path.join(root, 'mods', 'Civitas-test.jar'), 'civitas')
    await fs.writeFile(path.join(root, 'config', 'passwords.json'), '{"password":"PRIVATE"}')
    const publish = await collect(root)
    assert.ok(publish.every(f => !/saves|passwords|backups/.test(f.path)))
})

test('signed file URLs can download from separate storage without an account token', async t => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), 'humanitas-storage-'))
    const bytes = Buffer.from('external object storage'), sha256 = crypto.createHash('sha256').update(bytes).digest('hex')
    let requests = 0
    const remote = http.createServer((req, res) => { assert.equal(req.headers.authorization, undefined); requests++; res.end(bytes) })
    await new Promise(resolve => remote.listen(0, '127.0.0.1', resolve))
    t.after(async () => { await new Promise(resolve => remote.close(resolve)); await fs.rm(root, { recursive: true, force: true }) })
    await syncPack({ files: [{ path: 'mods/external.jar', sha256, size: bytes.length, mode: 'managed', url: 'http://127.0.0.1:' + remote.address().port + '/object' }] }, root, 'https://unused.example')
    assert.equal(await fs.readFile(path.join(root, 'mods', 'external.jar'), 'utf8'), bytes.toString())
    assert.equal(requests, 1)
})
