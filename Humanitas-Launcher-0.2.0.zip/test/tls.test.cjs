const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const { execFileSync } = require('node:child_process')
const { createService } = require('../service/server.cjs')
const { getJSON, setServiceCertificate } = require('../humanitas/files.cjs')

test('HTTPS service requires the pinned certificate and rejects a different identity', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'humanitas-tls-'))
    const openssl = process.platform === 'win32' ? 'C:/Program Files/Git/usr/bin/openssl.exe' : 'openssl'
    function cert(name) {
        const key = path.join(dir, name + '.key'), certificate = path.join(dir, name + '.pem')
        execFileSync(openssl, ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1', '-subj', '/CN=127.0.0.1', '-addext', 'subjectAltName=IP:127.0.0.1', '-keyout', key, '-out', certificate], { stdio: 'ignore' })
        return { key, certificate }
    }
    let service
    try {
        const a = cert('a'), b = cert('b')
        const [key, pem, wrong] = await Promise.all([fs.readFile(a.key), fs.readFile(a.certificate, 'utf8'), fs.readFile(b.certificate, 'utf8')])
        service = createService({ directory: path.join(dir, 'accounts'), release: dir, publicURL: 'https://127.0.0.1', tls: { key, cert: pem, minVersion: 'TLSv1.2' } })
        await new Promise(resolve => service.server.listen(0, '127.0.0.1', resolve))
        const origin = 'https://127.0.0.1:' + service.server.address().port
        await assert.rejects(getJSON(origin + '/health'))
        setServiceCertificate(origin, wrong)
        await assert.rejects(getJSON(origin + '/health'))
        setServiceCertificate(origin, pem)
        assert.equal((await getJSON(origin + '/health')).status, 'ok')
        const invite = service.store.invite(1, 'TlsTest')
        await getJSON(origin + '/api/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'TlsTest', password: 'a sufficiently long password', invite }) })
        const auth = await getJSON(origin + '/yggdrasil/authserver/authenticate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'TlsTest', password: 'a sufficiently long password', clientToken: 'test' }) })
        assert.equal(auth.selectedProfile.name, 'TlsTest')
        await assert.rejects(getJSON('https://localhost:' + service.server.address().port + '/health'))
    } finally {
        setServiceCertificate(null, null)
        if (service) await new Promise(resolve => service.server.close(resolve))
        await fs.rm(dir, { recursive: true, force: true })
    }
})
