# Humanitas Bridge

Server-side NeoForge 1.21.1 bridge for Humanitas Launcher. The optional account
service starts only when `service-enabled=true` is set in
`config/humanitas-bridge.properties`. Configure `port`, `public-url` and
`minecraft-server` for your installation. The server uses the bridge to check
sessions and requires `online-mode=true`.

Build with `gradlew build` and install the JAR from `build/libs/` in the server's
`mods/` directory. Running the account service also requires the service files,
Node.js runtime, a TLS certificate and its private key. Those deployment files,
account data and release files are intentionally not included in this source.
Do not publish private keys or the accounts database.

On a new host, test TLS, session validation, service startup and server settings
on an isolated test server before enabling it for players. Back up existing worlds
and account databases before changing authentication: player UUIDs can differ.
