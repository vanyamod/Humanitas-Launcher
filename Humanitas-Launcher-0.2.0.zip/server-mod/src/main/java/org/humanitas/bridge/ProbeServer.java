package org.humanitas.bridge;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
/** Public connectivity probe only. Never accepts credentials or exposes files. */
public final class ProbeServer implements AutoCloseable {
    private final HttpServer server;
    private final ThreadPoolExecutor workers;
    public ProbeServer(int port) throws IOException {
        server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 16);
        workers = new ThreadPoolExecutor(2, 2, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<>(32), r -> {
            Thread t = new Thread(r, "humanitas-bridge-probe"); t.setDaemon(true); return t;
        });
        server.setExecutor(workers);
        server.createContext("/", exchange -> {
            try {
                boolean ok = "GET".equals(exchange.getRequestMethod()) && "/health".equals(exchange.getRequestURI().getRawPath()) && exchange.getRequestURI().getRawQuery() == null;
                byte[] body = (ok ? "{\"service\":\"humanitas-bridge\",\"status\":\"probe\",\"auth\":false}" : "{\"error\":\"not found\"}").getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.getResponseHeaders().set("Cache-Control", "no-store");
                exchange.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
                exchange.sendResponseHeaders(ok ? 200 : 404, body.length);
                try (var out = exchange.getResponseBody()) { out.write(body); }
            } finally { exchange.close(); }
        });
    }
    public void start() { server.start(); }
    public int port() { return server.getAddress().getPort(); }
    @Override public void close() { server.stop(0); workers.shutdownNow(); }
}
