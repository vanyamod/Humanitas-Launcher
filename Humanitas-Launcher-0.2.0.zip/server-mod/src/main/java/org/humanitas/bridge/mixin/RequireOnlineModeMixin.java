package org.humanitas.bridge.mixin;

import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.login.ServerboundHelloPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.dedicated.DedicatedServer;
import net.minecraft.server.network.ServerLoginPacketListenerImpl;
import org.humanitas.bridge.ServerSessions;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerLoginPacketListenerImpl.class)
public abstract class RequireOnlineModeMixin {
    @Shadow @Final private MinecraftServer server;
    @Shadow public abstract void disconnect(Component reason);
    @Inject(method = "handleHello", at = @At("HEAD"), cancellable = true)
    private void humanitas$requireAuthentication(ServerboundHelloPacket packet, CallbackInfo callback) {
        if (!(server instanceof DedicatedServer)) return;
        try {
            if (!server.usesAuthentication() && ServerSessions.enabled()) {
                disconnect(Component.literal("Humanitas: online-mode must be true"));
                callback.cancel();
            }
        } catch (AuthenticationUnavailableException e) {
            disconnect(Component.literal("Humanitas authentication is unavailable"));
            callback.cancel();
        }
    }
}
