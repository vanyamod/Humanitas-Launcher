package org.humanitas.bridge;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

@Mod("humanitas_bridge")
public final class HumanitasBridge {
    private static final Logger LOG = LogUtils.getLogger();
    private ProbeServer probe;
    private Process accountService;
    public HumanitasBridge() {
        NeoForge.EVENT_BUS.addListener(this::start);
        NeoForge.EVENT_BUS.addListener(this::stop);
        NeoForge.EVENT_BUS.addListener(this::registerCommands);
    }
    private void start(ServerStartedEvent event) {
        try {
            Path config = Path.of("config", "humanitas-bridge.properties");
            Files.createDirectories(config.getParent());
            if (Files.notExists(config)) Files.writeString(config, "# Public TCP port allocated by the hosting panel\nport=14079\n");
            Properties values = new Properties();
            try (var input = Files.newInputStream(config)) { values.load(input); }
            int port = Integer.parseInt(values.getProperty("port", "14079"));
            if (port < 1 || port > 65535) throw new IllegalArgumentException("invalid port");
            if (Boolean.parseBoolean(values.getProperty("service-enabled", "false"))) {
                Path root = Path.of("humanitas-service").toAbsolutePath().normalize();
                Path node = root.resolve(System.getProperty("os.name").toLowerCase(java.util.Locale.ROOT).contains("win") ? "node/bin/node.exe" : "node/bin/node");
                Path server = root.resolve("service/server.cjs");
                Path key = root.resolve("private/server-key.pem");
                Path cert = root.resolve("private/server-cert.pem");
                for (Path required : new Path[] { node, server, key, cert }) {
                    if (!Files.isRegularFile(required)) throw new IOException("Missing service file: " + required);
                }
                if (!node.toFile().setExecutable(true, true) && !Files.isExecutable(node)) throw new IOException("Cannot mark Node runtime executable");
                ProcessBuilder process = new ProcessBuilder(node.toString(), server.toString());
                process.directory(root.toFile());
                process.redirectErrorStream(true);
                process.redirectOutput(ProcessBuilder.Redirect.INHERIT);
                var env = process.environment();
                String publicUrl = values.getProperty("public-url", "").strip();
                if (publicUrl.isEmpty()) throw new IOException("Set public-url to the service HTTPS address");
                env.put("PUBLIC_URL", publicUrl);
                env.put("PORT", Integer.toString(port));
                env.put("HUMANITAS_LISTEN", "0.0.0.0");
                env.put("HUMANITAS_TLS_KEY", key.toString());
                env.put("HUMANITAS_TLS_CERT", cert.toString());
                env.put("HUMANITAS_AUTH_DATA", root.resolve("private/accounts").toString());
                env.put("HUMANITAS_RELEASE", root.resolve("release/public").toString());
                String minecraftServer = values.getProperty("minecraft-server", "").strip();
                if (minecraftServer.isEmpty()) env.remove("MINECRAFT_SERVER");
                else env.put("MINECRAFT_SERVER", minecraftServer);
                env.remove("HUMANITAS_DEVELOPMENT");
                env.remove("TRUST_LOOPBACK_PROXY");
                accountService = process.start();
                accountService.onExit().thenAccept(child -> LOG.warn("Humanitas account service stopped with exit code {}", child.exitValue()));
                LOG.info("Humanitas account service starting on 0.0.0.0:{}", port);
                return;
            }
            probe = new ProbeServer(port);
            probe.start();
            LOG.info("Humanitas Bridge connectivity probe listening on 0.0.0.0:{}; login is not enabled", port);
        } catch (IOException | IllegalArgumentException e) {
            LOG.error("Humanitas Bridge could not open its connectivity probe", e);
        }
    }
    private void registerCommands(RegisterCommandsEvent event) {
        var root = Commands.literal("humanitasbridge").requires(source -> source.getEntity() == null && source.hasPermission(4));
        for (String action : new String[] { "invite", "admin", "unadmin", "block", "unblock", "logout" }) {
            root.then(Commands.literal(action).then(Commands.argument("player", StringArgumentType.word())
                .executes(ctx -> runAdmin(ctx.getSource(), action, StringArgumentType.getString(ctx, "player")))));
        }
        event.getDispatcher().register(root);
    }
    private int runAdmin(net.minecraft.commands.CommandSourceStack source, String action, String player) {
        if (!player.matches("[A-Za-z0-9_]{3,16}")) {
            source.sendFailure(Component.literal("Invalid player name")); return 0;
        }
        Path root = Path.of("humanitas-service").toAbsolutePath().normalize();
        try {
            ProcessBuilder command = new ProcessBuilder(root.resolve(System.getProperty("os.name").toLowerCase(java.util.Locale.ROOT).contains("win") ? "node/bin/node.exe" : "node/bin/node").toString(), root.resolve("service/admin.cjs").toString(), action, player);
            command.directory(root.toFile()); command.redirectErrorStream(true);
            command.environment().put("NODE_NO_WARNINGS", "1");
            command.environment().put("HUMANITAS_AUTH_DATA", root.resolve("private/accounts").toString());
            Process process = command.start();
            if (!process.waitFor(10, java.util.concurrent.TimeUnit.SECONDS)) { process.destroyForcibly(); throw new IOException("command timed out"); }
            String output = new String(process.getInputStream().readNBytes(2048), java.nio.charset.StandardCharsets.UTF_8).strip();
            if (process.exitValue() != 0) throw new IOException("command failed; check service configuration");
            source.sendSuccess(() -> Component.literal("Humanitas: " + output), false);
            return 1;
        } catch (IOException e) { source.sendFailure(Component.literal("Humanitas: " + e.getMessage())); return 0; }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); source.sendFailure(Component.literal("Humanitas: interrupted")); return 0; }
    }
    private void stop(ServerStoppingEvent event) {
        if (probe != null) { probe.close(); probe = null; }
        if (accountService != null) {
            accountService.destroy();
            try {
                if (!accountService.waitFor(5, java.util.concurrent.TimeUnit.SECONDS)) accountService.destroyForcibly();
            } catch (InterruptedException e) { accountService.destroyForcibly(); Thread.currentThread().interrupt(); }
            accountService = null;
        }
    }
}
