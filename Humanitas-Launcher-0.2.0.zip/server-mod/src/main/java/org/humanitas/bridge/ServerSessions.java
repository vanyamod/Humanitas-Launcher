package org.humanitas.bridge;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import com.mojang.authlib.yggdrasil.ProfileResult;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateFactory;
import java.util.Properties;
import java.util.UUID;

/** Server-only session validation. The local service certificate is the sole trusted authority. */
public final class ServerSessions {
    private ServerSessions() {}
    public static com.mojang.authlib.minecraft.MinecraftSessionService wrap(com.mojang.authlib.minecraft.MinecraftSessionService delegate) {
        return (com.mojang.authlib.minecraft.MinecraftSessionService) java.lang.reflect.Proxy.newProxyInstance(
                com.mojang.authlib.minecraft.MinecraftSessionService.class.getClassLoader(),
                new Class<?>[] { com.mojang.authlib.minecraft.MinecraftSessionService.class }, (proxy, method, args) -> {
                    if (method.getName().equals("hasJoinedServer") && enabled()) {
                        return verify((String) args[0], (String) args[1], (InetAddress) args[2]);
                    }
                    try { return method.invoke(delegate, args); }
                    catch (java.lang.reflect.InvocationTargetException e) { throw e.getCause(); }
                });
    }
    private static Properties settings() throws IOException {
        Properties p = new Properties();
        Path config = Path.of("config", "humanitas-bridge.properties");
        if (Files.exists(config)) try (var in = Files.newInputStream(config)) { p.load(in); }
        return p;
    }
    public static boolean enabled() throws AuthenticationUnavailableException {
        try { return Boolean.parseBoolean(settings().getProperty("service-enabled", "false")); }
        catch (IOException e) { throw new AuthenticationUnavailableException("Cannot read Humanitas service configuration", e); }
    }
    public static ProfileResult verify(String name, String serverId, InetAddress address) throws AuthenticationUnavailableException {
        if (name == null || !name.matches("[A-Za-z0-9_]{3,16}") || serverId == null || !serverId.matches("-?[0-9a-f]{1,40}")) return null;
        HttpsURLConnection connection = null;
        try {
            int port = Integer.parseInt(settings().getProperty("port", "14079"));
            if (port < 1 || port > 65535) throw new IOException("Invalid Humanitas service port");
            Path certificate = Path.of("humanitas-service", "private", "server-cert.pem");
            var factory = CertificateFactory.getInstance("X.509");
            java.security.cert.Certificate cert;
            try (var in = Files.newInputStream(certificate)) { cert = factory.generateCertificate(in); }
            KeyStore store = KeyStore.getInstance(KeyStore.getDefaultType());
            store.load(null, null); store.setCertificateEntry("humanitas", cert);
            TrustManagerFactory managers = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            managers.init(store);
            SSLContext context = SSLContext.getInstance("TLS");
            context.init(null, managers.getTrustManagers(), new SecureRandom());
            String query = "username=" + URLEncoder.encode(name, StandardCharsets.UTF_8)
                    + "&serverId=" + URLEncoder.encode(serverId, StandardCharsets.UTF_8)
                    + (address == null ? "" : "&ip=" + URLEncoder.encode(address.getHostAddress(), StandardCharsets.UTF_8));
            connection = (HttpsURLConnection) URI.create("https://127.0.0.1:" + port + "/yggdrasil/sessionserver/session/minecraft/hasJoined?" + query).toURL().openConnection();
            connection.setSSLSocketFactory(context.getSocketFactory());
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(5000); connection.setReadTimeout(5000);
            int status = connection.getResponseCode();
            if (status == 204) return null;
            if (status != 200) throw new IOException("Humanitas service status " + status);
            byte[] bytes;
            try (var in = connection.getInputStream()) { bytes = in.readNBytes(16385); }
            if (bytes.length > 16384) throw new IOException("Humanitas response is too large");
            JsonObject data = JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject();
            String id = data.get("id").getAsString(), canonicalName = data.get("name").getAsString();
            if (!id.matches("[0-9a-f]{32}") || !canonicalName.matches("[A-Za-z0-9_]{3,16}") || !canonicalName.equalsIgnoreCase(name)) return null;
            UUID uuid = UUID.fromString(id.replaceFirst("^(........)(....)(....)(....)(............)$", "$1-$2-$3-$4-$5"));
            if (!uuid.equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + canonicalName).getBytes(StandardCharsets.UTF_8)))) return null;
            return new ProfileResult(new GameProfile(uuid, canonicalName));
        } catch (Exception e) {
            throw new AuthenticationUnavailableException("Humanitas session service is unavailable", e);
        } finally { if (connection != null) connection.disconnect(); }
    }
}
