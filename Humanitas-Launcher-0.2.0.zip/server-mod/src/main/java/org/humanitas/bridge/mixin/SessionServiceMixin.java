package org.humanitas.bridge.mixin;

import com.mojang.authlib.minecraft.MinecraftSessionService;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.dedicated.DedicatedServer;
import org.humanitas.bridge.ServerSessions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftServer.class)
public abstract class SessionServiceMixin {
    @Inject(method = "getSessionService", at = @At("RETURN"), cancellable = true)
    private void humanitas$verify(CallbackInfoReturnable<MinecraftSessionService> callback) {
        if ((Object) this instanceof DedicatedServer) callback.setReturnValue(ServerSessions.wrap(callback.getReturnValue()));
    }
}
